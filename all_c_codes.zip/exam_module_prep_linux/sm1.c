#include"header.h"

int main()
{
   int id;

   id=shmget(4,50,IPC_CREAT|0664);
   if(id<0)
   {
     perror("shmget");
     return 0;

   }

   printf("id=%d",id);

   char *p;
   p=shmat(id,0,0);

   printf("enter the strinig\n");
   scanf("%s",p);
}
