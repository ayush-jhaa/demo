#include "header.h"

int main()
{
  int r;

  r=fork();

  if(r==0)
  {
     printf("in child pid=%d\n ",r);
  }
  else
  {
    printf("in parent pid=%d\n",r);
  }

  while(1);
}
