#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int p1[2], p2[2];
    pipe(p1);
    pipe(p2);

    if (fork() == 0) {
        // Child 1: ps -l
        close(p1[0]); // Close unused read end of first pipe
        dup2(p1[1], STDOUT_FILENO); // Redirect stdout to write end of first pipe
        close(p1[1]); // Close original stdout
        close(p2[0]); // Close unused read end of second pipe
        close(p2[1]); // Close unused write end of second pipe
        execlp("ps", "ps", "-l", NULL); // Execute ps -l
    } else {
        if (fork() == 0) {
            // Child 2: grep pts
            close(p1[1]); // Close unused write end of first pipe
            dup2(p1[0], STDIN_FILENO); // Redirect stdin to read end of first pipe
            close(p1[0]); // Close original stdin
            close(p2[0]); // Close unused read end of second pipe
            dup2(p2[1], STDOUT_FILENO); // Redirect stdout to write end of second pipe
            close(p2[1]); // Close original stdout
            execlp("grep", "grep", "pts", NULL); // Execute grep pts
        } else {
            if (fork() == 0) {
                // Child 3: wc
                close(p1[0]); // Close unused read end of first pipe
                close(p1[1]); // Close unused write end of first pipe
                close(p2[1]); // Close unused write end of second pipe
                dup2(p2[0], STDIN_FILENO); // Redirect stdin to read end of second pipe
                close(p2[0]); // Close original stdin
                execlp("wc", "wc", NULL); // Execute wc
            } else {
                // Close all pipe descriptors in parent process
                close(p1[0]);
                close(p1[1]);
                close(p2[0]);
                close(p2[1]);

                // Wait for all child processes to finish
                wait(NULL);
                wait(NULL);
                wait(NULL);
            }
        }
    }

    return 0;
}

