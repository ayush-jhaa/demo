#include"header.h"

int main()
{
   
   printf("hello");
   return 0;
  _exit(0);
}
