#include"header.h"

int main()
{
    int p[2];

   pipe(p);

   if(fork()==0)
   {
      //child
      char b[15];
      printf("in child for reading pid %d\n",getpid());
      read(p[0],b,sizeof(b));
      printf("after child read\n");
      printf("%s\n",b);
   }
   else
   {
      // parent

	char b[15];
	printf("in parent for writing pid %d\n",getpid());
	scanf("%[^\n]s",b);
	printf("after parent write\n");

	write(p[1],b,strlen(b)+1);
   }
//   while(1);
}
