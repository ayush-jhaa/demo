#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int cnt;
typedef struct student
{
   int id;
   char *name;
   float marks;
}stu;

char *getstring(void)
{
     int i=0;
     char *p=NULL;

     do
     {
         p=realloc(p,(i+1)*sizeof(char));
	 p[i]=getchar();
     }while(p[i++]!='\n');

     p[i-1]='\0';

     return p;
}

stu *INPUT(stu *p)
{
  p=realloc(p,(cnt+1)*sizeof(stu));

  printf("enter the id:");
  scanf("%d",&p[cnt].id);
  printf("enter the name:");
  __fpurge(stdin);
  p[cnt].name=getstring();
  printf("enter the marks:");
  scanf("%f",&p[cnt].marks);

  cnt++;
  return p;
   
}

void sort(stu *p)
{
     int i=0,j=0;
     stu temp;

     for(i=0;i<cnt-1;i++)
     {
        for(j=0;j<cnt-i-1;j++)
	{
	      if(strcmp(p[j].name,p[j+1].name)>=1)
	      {
	        temp=p[j];
	        p[j]=p[j+1];
		p[j+1]=temp;	
	      }

	}
     }
     
}
void print(stu *p)
{
    int i=0;
    for(i=0;i<cnt;i++)
    {
        printf("%d %s %.2f",p[i].id,p[i].name,p[i].marks);
	printf("\n");
    }
}
int main()
{
     stu *p=NULL;

     char choice;
     while(1)
     {
        printf("---i:- input--- p:- print----s:- sort----q:- quit");
	scanf(" %c",&choice);
     
	switch(choice)
        {
	    case 'i': p=INPUT(p);
		      break;
	    case 's': sort(p);
		      break;
            case 'p': print(p);
		      break;
	    
            case 'q': return 0; 
	}
     }  

}
