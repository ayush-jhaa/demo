#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char * getstring(void)
{
   char *p=NULL;
   int i=0;

   do
   {
      p=realloc(p,(i+1));
      p[i]=getchar();

   }while(p[i++] !='\n');

   p[i-1]='\0';

   return p;
}
int main()
{
    printf("enter main string:\n");
    char *main=NULL;
    main=getstring();

    char *prevs=NULL;
    printf("enter substring:\n");
    prevs=getstring();
    printf("enter new substring:\n");
    int l2=strlen(prevs);

    char *news=NULL;
    news=getstring();
    int l3=strlen(news);

    char *p=main;


    while((p=strstr(p,prevs))!=NULL)
    {
        memmove(p+l3,p+l2,strlen(p+l2)+1);
	strncpy(p,news,l3);
	p=p+l3;
    }

    printf("%s",main);
}
