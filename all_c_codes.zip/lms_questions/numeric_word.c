// convert numeric to word


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

void num_word(char *str)
{
    int l=strlen(str);
    const char dig[10][10]={"ZERO","ONE","TWO","THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE"};

    while(*str)
    {
        if(isdigit(*str))
        {
	   printf("%s",dig[*str-'0']);
	}

	else
	{
	   printf("%c",*str);
	}
	str++;
    }

}

int main()
{
     char str[50];
     fgets(str,50,stdin);

     num_word(str);
}
