#include<stdio.h>
#include<string.h>

int main()
{
     char s1[100]="this is vector india hello india from vector";
     char s2[20]="india";
     char s3[20]="hyderabad";

     int l2=strlen(s2);
     int l3=strlen(s3);

     char *p=s1;

     while(p=strstr(p,s2))
     {
        memmove(p+l3,p+l2,strlen(p+l2)+1);
	strncpy(p,s3,l3);
//	strcpy(p,s3);
	p=p+l3;
     }

     printf("%s",s1);
}

