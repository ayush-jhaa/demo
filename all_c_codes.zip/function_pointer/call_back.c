#include<stdio.h>

int sum(int,int);
int div(int,int);
int mul(int,int);
int sub(int,int);
int Indirect_call(int,int,int(*p)(int,int));

int main()
{
   int m=10,n=20,r;

   r=Indirect_call(m,n,sum);
 
   printf("the sum is %d again",r);   
}


int Indirect_call(int i, int j,int(*p)(int ,int))
{
   int res;
   res=(*p)(i,j);
   return res;
}

int sum(int i,int j)
{
   return i+j;
}

int div(int i,int j)
{
    return (i/j);
}

int sub(int i,int j)
{
   return i-j;
}

int mul(int i,int j)
{
   return i*j;
}
