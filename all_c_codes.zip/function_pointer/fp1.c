#include<stdio.h>

int sum(int,int);
int div(int,int);
int mul(int,int);
int sub(int,int);

int main()
{
   int m=10,n=20,r;
   int (*p)(int,int);

// r=sum(m,n);
// printf("the sum is :%d\n",r);
  
   p=sum;
   p=sub;
   r=(*p)(m,n);
   printf("the sum is %d again",r);
   
}

int sum(int i,int j)
{
   return i+j;
}

int div(int i,int j)
{
    return (i/j);
}
int sub(int i,int j)
{
   return i-j;
}
int mul(int i,int j)
{
   return i*j;
}
