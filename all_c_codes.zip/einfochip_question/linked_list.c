#include<stdio.h>
#include<stdlib.h>

int size;

typedef struct st
{
    int data;
    struct st *link,*prev;

}struc;


struc *add(struc *head)
{
     struc *newnode=NULL;
     newnode=calloc(1,sizeof(struc));
     size++;

     if(newnode==NULL)
     {
       printf("node not created");
     }

     else
     {
        printf("enter data...\n");
	scanf("%d",&newnode->data);

	newnode->link= head;
	if(head)
	{
	   head->prev=newnode;
	}
	head=newnode;
     }

     return head;
}

void print(struc *ptr)
{
     if(ptr==NULL)
     {
          printf("list is empty...\n");
     }
     else
     {
	  while(ptr)
	 {
          printf("%d ",ptr->data);
	  ptr=ptr->link;
	 }
     }
}

struc *sort(struc *head)
{
   int var;
   int i=1;
   int tempdata;
   printf("enter the n to sort..\n");
   scanf("%d",&var);
   int j=var;


   struc *temp=head;
   struc *temp2=head;

   if(var>size)
   {
     printf("sorry requested input is larger than expected..\n");
     return 0;
   }

   for(int k=1;k<var;k++)
   {
      temp2=temp2->link;
   }

   while(j>i)
   {
      tempdata=temp->data;
      temp->data=temp2->data;
      temp2->data=tempdata;

      j--;
      i++;

      temp=temp->link;
      temp2=temp2->prev;
   }

        return head;   


}


int main()
{
    struc *head=NULL;

    int choice;
    
    while(1)
    {
	printf("enter your choice 1.add 2.print 3.sort\n");
	scanf("%d",&choice);

        switch(choice)
	{
	    case 1: head=add(head);
		    break;
	    case 2: print(head);
		    break;
	    case 3: head=sort(head);
		    break;
	}
    }
}
