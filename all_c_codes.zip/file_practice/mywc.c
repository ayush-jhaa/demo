#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char *readfromfile(char *filename)
{
       FILE *fp=NULL;
       int size;
       char *p=NULL;
       fp=fopen(filename,"r");
       if(fp==NULL)
       {
          printf("file not found \n");
	  return NULL;
       }
       fseek(fp,0,2);
       size=ftell(fp)+1;
       rewind(fp);
       p=calloc(1,size);
       fread(p,size,1,fp);
       p[size]='\0';
       fclose(fp);

       return p;
       
}

int count_all(char *str,char ch)
{
    char *q=str;

    int count=0;

    while(q=strchr(q,ch))
    {
       count++;
       q++;
    }

    return count;
}

int main(int argc,char *argv[])
{
    char *p=NULL;
    int scnt,lcnt;

    if(argc !=2)
    {
        printf("argument supplied is less or more\n");
	return 0;
    }

    p=readfromfile(argv[1]);
    scnt=count_all(p,32);
    lcnt=count_all(p,10);

    printf("number of character in files are %d\n",strlen(p));
    printf("number of words in files are %d\n",scnt+lcnt);

}
