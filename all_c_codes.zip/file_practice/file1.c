#include:"header.h"

char *readfromfile(char* filename)
{
	FILE *fp=NULL;
	char *p;
	int size;
	fp=fopen(filename,"r");
	if(fp==NULL)
	{
	   printf("file not found\n");
	   return 0;
	}
	fseek(fp,0,2);
	size=ftell(fp)+1;
	rewind(fp);
	p=calloc(1,size);
	p[size]='\0';
	fread(p,size,1,fp);
	fclose(fp);
	return p;

      
}

void reverse(char *s1,char *s2)
{
    char *temp=NULL;
    char *p,*q,*r,ch;
    int l2=strlen(s2);

    for(temp=s1;temp=strstr(temp,s2);temp+=l2)
    {
            r=temp;
            --r;
	    if((*r)==' ')
	    {
	          p=temp;
		  q=temp+l2-1;

		  while(p<q)
	          {
		      ch=*p;
		      *p=*q;
		      *q=ch;
		      p++;
		      q--;
		  }
	    }
    }

}

void printfile(char *s1,char *filename)
{
   FILE *fp=NULL;
   fp=fopen(filename,"w");
   fprintf(fp,"%s",s1);
   fclose(fp);
}

int main(int argc,char *argv[])
{
     char *p;

     p=readfromfile(argv[1]);
     reverse(p,argv[2]);
     printfile(p,argv[1]);
     
}
