#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char *readfromfile(char *filename)
{
   FILE *fp;
   int size;
   char *p;
   fp=fopen(filename,"r");
   if(fp==NULL)
   {
      printf("filename not found\n");
      return NULL;
   }
   
   fseek(fp,0,2);
   size=ftell(fp)+1;
   rewind(fp);
   p=calloc(1,size);
   fread(p,size,1,fp);
   p[size]='\0';

   fclose(fp);
   return p;


}
void writetofile(char *filename,char *p)
{
     FILE *fp=NULL;
     fp=fopen(filename,"w");
     fwrite(p,strlen(p),1,fp);
     fclose(fp);
}

int main(int argc,char *argv[])
{
      char *p=NULL;

      if(argc !=3)
      {
         printf("data not enter correctly\n");
	 return NULL;
      }

      p=readfromfile(argv[1]);
      writetofile(argv[2],p);
}
