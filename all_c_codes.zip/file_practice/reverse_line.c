#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void REVERSE(char *str)
{
   int i=0,j;
   char ch;
   j=strlen(str)-2;

   for(i=0;i<j;i++,j--)
   {
    ch=str[i];
    str[i]=str[j];
    str[j]=ch;
   }
}

void *reverseline(char *filename)
{
 FILE *fp;
 char str[100];
 fp=fopen(filename,"r+");

 while(fgets(str,100,fp))
 {
       REVERSE(str);
       fseek(fp,-strlen(str),1);
       fputs(str,fp);
 }	 

 fclose(fp);
}

int main(int argc, char *argv[])
{
   char *p;
   if(argc !=2)
   {
      printf("wrong entry\n");
      return 0;
   }

   reverseline(argv[1]);
}
