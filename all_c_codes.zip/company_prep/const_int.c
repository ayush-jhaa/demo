#include <stdio.h>

int main()
{
    volatile const int  v=100;
    int *p=&v;
    ++*p;
    printf("%d",v);

    return 0;
}

