#include <stdio.h>

int main()
{
    int i=10;
    
    const int *p;
    
    p=&i;
    *++p;
    
    printf("%d",*p);

    return 0;
}

