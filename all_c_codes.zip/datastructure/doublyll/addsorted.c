#include "header.h"

stu *addsorted(stu *ptr)
{
     stu *newnode=NULL;
     stu *temp=NULL;
     stu *temp2=NULL;
     newnode=calloc(1,sizeof(stu));

     if(newnode==NULL)
     {
       printf("node not created\n");
       return ptr;
     }

     printf("enter the id\n");
     scanf("%d",&newnode->id);
     printf("enter the name\n");
     __fpurge(stdin);
     newnode->name=getstring();

     if (ptr == NULL)
{
    newnode->link = ptr;
    newnode->prev = NULL;
    ptr = newnode;
}


     else
     { 
	     temp=ptr;

	     while(temp  && newnode->id > temp->id)
	     {
		temp2=temp;
		temp=temp->link;	     
	     }
	    
	     if(temp==NULL)
{
    newnode->link=temp;
    newnode->prev=temp2;
    if(temp2 != NULL)
    {
        temp2->link=newnode;
    }
    else
    {
        // If temp2 is NULL, it means newnode is the first node
        // Update the pointer to the first node
        ptr = newnode;
    }
}

          
     }

     return ptr;

}
