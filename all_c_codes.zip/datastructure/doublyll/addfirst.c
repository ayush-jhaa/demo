#include "header.h"

stu *addfirst(stu *ptr)
{
	stu *newnode=NULL;
	newnode=calloc(1,sizeof(stu));

	if(newnode==NULL)
	{
	    printf("node not found");
	    return 0;
	}
	
	printf("enter the roll data:");
	scanf("%d",&newnode->id);
	printf("enter the name:");
	__fpurge(stdin);
	newnode->name=getstring();

	newnode->link=ptr;
	if(ptr)
	{
	  ptr->prev=newnode;
	}
	ptr=newnode;

	
	return ptr;

}
