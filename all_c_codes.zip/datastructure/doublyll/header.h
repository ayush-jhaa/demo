#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
typedef struct student
{
       int id;
       char *name;
       struct student *prev;
       struct student *link;
}stu;

char *getstring(void);

stu *addfirst(stu *ptr);
void print(stu* ptr);
stu *delfirst(stu *ptr);
stu *addsorted(stu *ptr);
stu *deldata(stu *ptr);
stu *dellast(stu *ptr);
stu *addlast(stu *ptr);
