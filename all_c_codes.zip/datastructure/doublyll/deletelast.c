#include "header.h"

stu *dellast(stu *ptr)
{
       stu *temp=NULL;

       if(ptr==NULL)
	{
	  printf("data not found");
	}

       else if(ptr->link==NULL)
	{
	   free(ptr);
	   ptr=NULL;
	   return ptr;
	}
      else
	{
           temp=ptr;

           while(temp->link)
          {
                temp=temp->link;
          }
	   (temp->prev)->link=NULL;

	   free(temp);

	}

      return ptr;
       
}
