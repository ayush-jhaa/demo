#include "header.h"

char *getstring(void)
{
    char *p=NULL;
    int i=0;
    do
    {
       p=realloc(p,(i+1)*sizeof(char));
       p[i]=getchar();
    }while(p[i++] !=10);

    p[i-1]='\0';

    return p;
}

