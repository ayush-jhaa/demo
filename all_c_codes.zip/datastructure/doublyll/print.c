#include "header.h"
void print(stu *ptr)
{
    if(ptr==NULL)
    {
        printf("not found\n");
	return;
    }

    while(ptr)
    {
       printf("%d %s\n",ptr->id,ptr->name);
       ptr=ptr->link;
    
    }
}
