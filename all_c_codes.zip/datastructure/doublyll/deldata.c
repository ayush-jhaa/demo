#include "header.h"

stu *deldata(stu *ptr)
{
     int data;
     stu *temp=NULL;
     printf("ENTER DATA TO DELETE\n");
     scanf("%d",&data);

     if(ptr==NULL)
     {
        printf("list is empty\n");

     }

     else if(ptr->id ==data)
     {
	     temp=ptr;
	     ptr=ptr->link;
	     ptr->prev=NULL;
	     free(temp);
         
     }
     else
     {
	     temp=ptr;
     while(temp && temp->id !=data)
     {
         temp=temp->link;
     }

     if(temp==NULL)
     {
        printf("data not found\n");
     }
     else
     {
       temp->prev->link=temp->link;
		if(temp->link)
		temp->link->prev=temp->prev;
		free(temp);
     }

     }

     return ptr;

}
