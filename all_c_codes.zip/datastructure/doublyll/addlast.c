#include "header.h"
stu *addlast(stu *ptr)
{
     stu *newnode=NULL;
     stu *temp=NULL;
     newnode=calloc(1,sizeof(stu));

     if(newnode==NULL)
     {
          printf("node is not there\n");
	  return 0;
     }

     printf("enter id:\n");
     scanf("%d",&newnode->id);
     printf("enter the name:");
     __fpurge(stdin);
     newnode->name=getstring();

     if(ptr==NULL)
     {
       ptr=newnode;
     }

     else
     {
        temp=ptr;

	for(temp;temp->link;temp=temp->link);
	temp->link=newnode;
	newnode->prev=temp;
	
     }
	
     return ptr;
}
