#include "header.h"

stu *delfirst(stu *ptr)
{
     stu *temp=NULL;

     if(ptr==NULL)
     {
	   printf("node not present\n");
	    return 0;
     }

     else if(ptr->link==NULL)
     {
          free(ptr);
	  ptr=NULL;
     }
     else
     { 
     temp=ptr;
     ptr=ptr->link;
     ptr->prev=NULL;
     free(temp);

     }

     return ptr;

}
