#include "header.h"

int main()
{
    stu *p=NULL;
     char choice;

     while(1)
     {
         printf("addfirst:a ,addlast:b ,addsorted:c ,print:p ,deletefirst:d ,deletelast:e ,deletedata:f ,q:quit ,reverse:r\n");
	 printf("enter your choice\n");
	 __fpurge(stdin);
	 scanf("%c",&choice);

	 switch(choice)
	{
		case 'a':p=addfirst(p);
			 break;
		case 'b':p=addlast(p);
			 break;
		case 'c':p=addsorted(p);
			 break;
		case 'd':p=delfirst(p);
			 break;
		case 'e':p=dellast(p);
			 break;
		case 'f':p=deldata(p);
			 break;
		case 'p':print(p);
			 break;
		case 'q': return 0;
			  
	        
	}
     }
}
