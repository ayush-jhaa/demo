#include<stdio.h>
#include<stdlib.h>
#define MAX 5


int stack[MAX];
int top=-1;

void push(int);
int pop(void);
int peek(void);
void print(int *);
int main()
{
   int data,choice;
   while(1)
   {

STATEMENT:      printf("1.Push 2.Pop 3.Peek 4.print 5.exit\n");
                printf("enter the choice\n");
                scanf("%d",&choice);
       switch(choice)
        {
               case 1: printf("enter data: ");
                         scanf("%d",&data);
                         push(data);
                         break;

              case 2:  if(top==-1)
                         printf("stack is empty");
                         else{
                            printf("data poped is %d\n",pop());
                        }
                         break;

             case 3:  if(top==-1)
                         printf("stack is empty");
                         else{
                            printf("data peeked is %d\n",peek());
                         }
                         break;

            case 4: print(stack);
                    break;

             case 5: return 0;


        }
   }
}

void push(int data)
{
    if(top==MAX-1)
     printf("stack is  full\n");

    else
     {
         stack[++top]=data;
     }
}

int pop(void)
{
    return stack[top--];
}

int peek(void)
{
    return stack[top];
}

void print(int *stack)
{
    int i=0;

    for(i=0;i<=top;i++)
     {
        printf("%d\n",stack[i]);
     }
}
