#include "header.h"

stu *add_at_n(stu *head)
{
   stu *temp=NULL;
   stu *prev=NULL;
   int num;
   stu *newnode=NULL;
   newnode=calloc(1,sizeof(stu));
   
   if(newnode==NULL)
   {
      printf("node not present\n");
      return head;
   }

   printf("enter nth node to add:\n");
   scanf("%d",&num);

   printf("enter the id:\n");
   scanf("%d",&newnode->id);
   printf("enter the name\n");
   __fpurge(stdin);
   scanf("%s",newnode->name);

   //logic

   
   temp=head;

   if(num==0)           // node 0 not exist in linked list
   {
      printf("node does'nt exist\n");  
      return head;
   }

   else if(num==1)      //  adding node at first position not merging with else because in else prev also present for traversing here not require.
   {
       newnode->link=head;
       head=newnode;
   }

   else
   {

   	while((num>1) && (temp!=NULL))    //traversing to find nth node.
   	{
      		prev=temp;
      		temp=temp->link;
      		num--;
   	}

	  if(temp==NULL && num>1)   // (num>1) is for adding the data at last node if num supplies that node.
	  {
	     printf("nth node not present\n");
	  }
	  else                        // adding the nth node.
	  {
   		prev->link=newnode;
   		newnode->link=temp;
	  }

   }
   return head;

}
