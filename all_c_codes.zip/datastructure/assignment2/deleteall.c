#include "header.h"

stu *deleteall(stu *head)
{
	stu *temp=NULL;

	if(head==NULL)
	{
	  printf("node not present\n");
	  
	}
      
	else
	{
	do
	{
	   temp=head;
	   head=head->link;
	   free(temp);
	}while(head !=NULL);

	}

	return head;
}
