#include "header.h"

void middle_info(stu *ptr)
{ 
    stu *prev = ptr; 
    stu *next = ptr; 
 
    if (ptr!=NULL) 
    { 
        while (next != NULL && next->link != NULL) 
        { 
            next = next->link->link; 
            prev = prev->link; 
        } 

        printf("The middle element is %d\n",prev->id); 
    } 

} 

