#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>

typedef struct STUDENT
{
      int id;
      char name[20];
      struct STUDENT *link;
}stu;

stu *add(stu *);
stu *add_at_n(stu *);
stu *deleteall(stu *);
void search(stu *);
void middle_info(stu *);
void print(stu *);
void search_name(stu *);
