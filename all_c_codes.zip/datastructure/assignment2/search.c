#include "header.h"

void search(stu *ptr)
{
     int num;
     stu *temp=NULL;
     printf("enter the id to search");
     scanf("%d",&num);

     if(ptr==NULL)
     {
        printf("node not present\n");
	return;
     }

     temp=ptr;

     while( temp &&(temp->id !=num))
     {
        temp=temp->link;
     }

     if(temp==NULL)
	{
	  printf("node not found\n");
	}

     else
      {
          printf("node found\n");
          printf("%d %s\n",temp->id,temp->name);  
      }
}
