#include "header.h"

int main()
{
   char ch;
   stu *head;

   while(1)
   {
      printf("a.add ,b.add_at_nth ,d.deleteall ,s.search_on_id ,t:search_on_name  ,p:print ,m.middle_node_info ,q:quit\n");
      printf("enter your choice:\n");
      __fpurge(stdin);
      scanf("%c",&ch);

      switch(ch)
      {
         case 'a': head=add(head);
		   break;
	 case 'b': head=add_at_n(head);
		   break;
	 case 'd': head=deleteall(head);
		   break;
	 case 's': search(head);
		   break;
	 case 't': search_name(head);
		   break;
	 case 'm': middle_info(head);
		   break;
	 case 'p': print(head);
		   break;
	 case 'q': return 0;

      }
   }

}
