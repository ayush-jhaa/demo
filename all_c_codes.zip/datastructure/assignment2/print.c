#include "header.h"

void print(stu *head)
{
	if(head==NULL)
	{
	   printf("node not present\n");
	   return;
	}

    
	while(head !=NULL)
	{
	  printf("%d %s\n",head->id,head->name);
	  head=head->link;
	}

	
}
