#include "header.h"

stu *add(stu *head)
{
   stu *newnode=NULL;
   stu *temp=NULL;
   stu *prev=NULL;
   newnode=calloc(1,sizeof(stu));

   if(newnode==NULL)
   {
     printf("node not present\n");
     
   }

   else
   {
       printf("enter the id:");
       scanf("%d",&newnode->id);
       printf("enter name:");
       __fpurge(stdin);
       scanf("%s",newnode->name);

       if(head==NULL || newnode->id < head->id)
	{
	   newnode->link=head;
	   head=newnode;
	}
       
       else 
	{
	   temp=head;

	   while(temp && newnode->id > temp->id)
	   {
	       prev=temp;
	       temp=temp->link;
	   }
	   prev->link=newnode;
	   newnode->link=temp;
	   
	}
   }

    return head;
}
