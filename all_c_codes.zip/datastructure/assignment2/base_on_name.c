#include "header.h"

void search_name(stu *ptr)
{
     char user[15];
     stu *temp=NULL;
     printf("enter the id to search: ");
     scanf("%s",user);

     if(ptr==NULL)
     {
        printf("node not present\n");
	return;
     }

     temp=ptr;

     while( temp && (strcmp(temp->name,user)!=0))
     {
        temp=temp->link;
     }

     if(temp==NULL)
	{
	  printf("node not found\n");
	}

     else
      {
          printf("node found\n");
          printf("%d %s\n",temp->id,temp->name);  
      }
}
