#include "header.h"

STUDENT *Addlast(STUDENT *head)
{
	STUDENT *newnode=NULL;
	STUDENT *temp=NULL;
	newnode=calloc(1,sizeof(STUDENT));
	if(newnode==NULL)
        {
	    printf("list is empty\n");
	}
	else
	{
	    printf("enter the roll: ");
	    scanf("%d",&newnode->roll);
	    printf("enter the naame: ");
	    scanf("%s",newnode->name);

	   if(head==NULL)
	    {
	         head=newnode;
	    }
	   else
	    { temp=head;
	      
	       while(temp->link !=NULL)
		 {
		     temp=temp->link;
		 
		 }
	         temp->link=newnode;
	       
	    }
	}
	return head;
}
