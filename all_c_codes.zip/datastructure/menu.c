#include "header.h"

int main()
{
     STUDENT *head=NULL;
     char choice;

     while(1)
     {
        printf("A.ADDlast b:Addfirst c:delete_last  P.PRINT D.DELETE_first Q.QUIT\n");
	printf("enter your choice :");
	__fpurge(stdin);
	scanf("%c",&choice);

	switch(choice)
	{
	
	    case 'a': head=Addlast(head);
		      break;
	    case 'b': head=addfirst(head);
		      break;
	    case 'c': head=deletelast(head);
		      break;
	    case 'd': head=Deletefirst(head);
		      break;
	    case 'p': Print(head);
		      break;
	    case 'q': return 0;
	}
	
     
     }
         
}
