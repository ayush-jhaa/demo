#include "header.h"

STUDENT *deletelast(STUDENT *head)
{
    STUDENT *temp=NULL;
    STUDENT *temp2=NULL;
     if(head==NULL)
      printf("list is not present\n");

     else if(head->link ==NULL)
      {
         free(head);
	 head=NULL;
      }

     else
      {
           temp=head;
	   temp2=head;

	   while(temp->link !=NULL)
	   {
	         temp2=temp;
		 temp=temp->link;
	   }
	   temp2->link=NULL;
	   free(temp);
	   temp=NULL;
      }

     return head;

}


