#include<stdio.h>
#include<stdlib.h>

typedef struct Student
{
   int roll;
   char name[20];
   struct Student *link;
}STUDENT;

STUDENT *Addlast(STUDENT *);
STUDENT *Deletefirst(STUDENT *);
void Print(STUDENT *);
STUDENT *addfirst(STUDENT *);
STUDENT *deletelast(STUDENT *);
