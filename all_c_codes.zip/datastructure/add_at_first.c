#include "header.h"

STUDENT *addfirst(STUDENT *head)
{
     STUDENT *temp=NULL;
     STUDENT *newnode=NULL;

     newnode=calloc(1,sizeof(STUDENT));
     if(newnode==NULL)
	{
	    printf("data is not there\n");
	
	}
     else
	{
		printf("enter id:");
		scanf("%d",&newnode->roll);
		printf("enter name:");
		scanf("%s",newnode->name);

		if(head==NULL)
	        {
		   head=newnode;
		}
		else
	        {
		    newnode->link=head;
		    head=newnode;
		     
		}
	     
	}
     return head;

     
}

