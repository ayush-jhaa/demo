#include "header.h"

STUDENT *Deletefirst(STUDENT *head)
{
      STUDENT * temp=NULL;
      if(head==NULL)
      {
          printf("list is not there\n");
      }
      else
      {
           temp=head;
	   head=head->link;
	   free(temp);
      }

      return head;

}
