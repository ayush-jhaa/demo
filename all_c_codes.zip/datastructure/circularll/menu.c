#include"header.h"

int main()
{
   STUDENT *head=NULL;
   char choice;

   while(1)
   {
      printf("Add:-a Delete:-d print:-p quit:-q \n");
      __fpurge(stdin);
      scanf("%c",&choice);

      switch(choice)
      {
          case 'a': head=Addsorted(head);
                    break;
//          case 'd': head=Deletedata(head);
//                    break;
          case 'p': print(head);
                    break;
          case 'q': return 0;
     }
   }
}

