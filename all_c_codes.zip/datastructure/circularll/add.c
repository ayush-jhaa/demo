#include "header.h"

STUDENT* Addsorted(STUDENT* head) {

    int flag=0;
    STUDENT* newnode = NULL;
    STUDENT* temp = NULL;
    newnode = calloc(1, sizeof(STUDENT));

    if (newnode == NULL) {
        printf("node not created\n");
        return 0;
    }

    printf("enter id:\n");
    scanf("%d", &newnode->id);

    if (head == NULL) 
    {
        newnode->link = newnode;
        newnode->prev = newnode;
	head=newnode;

    } 
    
    else if (newnode->id < head->id) 
    {
        (head->prev)->link=newnode->prev;	
        newnode->prev = head->prev;
        newnode->link=head;
	head->prev=newnode;
       
        head = newnode;
    }
   
    else 
    {

        temp = head;
        temp = temp->link; // Start from the next node to avoid adding at last

        while (newnode->id > temp->id) 
	{
            if (temp->link == head) 
	    {
		flag++;
                break; // Break the loop when we reach the last node
            }
            temp = temp->link;
        }
        
	//inserting at last node
		if(flag)
        	{

	     	(temp->link)->prev=newnode;
	     	newnode->link=temp->link;
	     	newnode->prev=temp;
	     	temp->link=newnode;

		}

	// inserting at correct post
		else
        	{

        	(temp->prev)->link = newnode;
        	newnode->prev = temp->prev;
        	newnode->link = temp;
        	temp->prev = newnode;

		}

    }

    return head;
}
