#include "header.h"

void print(STUDENT *head)
{
   STUDENT *temp=NULL;
   temp=head;

   if(temp==NULL)
   {
    printf("node not present\n");
    return;
   }

   do
   {
      printf("%d ",temp->id);
      temp=temp->link;
   }while(temp != head);

  
}

