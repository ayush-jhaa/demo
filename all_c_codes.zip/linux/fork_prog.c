#include"header.h"

int main()
{
    int r;
    printf("Hello pid=%d\n",getpid());
    r=fork();
    if(r==0)
    {
        printf("In child......\n");
    }
    else
    {
      printf("In parent.....\n");
    }
    printf("Common code.....\n");

    while(1);
}
