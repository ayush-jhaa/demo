#include"header.h"

// default  action of sigalarm is process termination
void my_isr(int n)
{
     printf("pid of my_isr=%d\n",n);

}

int main()
{
   printf("Hello pid=%d\n",getpid());
   
   signal(SIGALRM,my_isr);
   alarm(2);

   printf("Hai....\n");

   while(1);
}
