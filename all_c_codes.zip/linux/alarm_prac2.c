#include"header.h"

void my_isr(int n)
{
     printf("pid of my_isr=%d\n",n);
     alarm(2);
}

int main()
{
   printf("Hello pid=%d\n",getpid());
   
   signal(SIGALRM,my_isr);
   alarm(5);

   printf("Hai....\n");

   while(1);
}
