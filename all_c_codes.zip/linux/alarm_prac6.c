#include"header.h"

void my_isr(int)
{
       printf("in isr\n");
}

int main()
{
   int r;
   printf("hello pid=%d\n",getpid());
   

   signal(14,my_isr);

   r=alarm(5);
   sleep(10);    // ANY PROCESS IN SLEEP AND IT RECIEVE ALARM IT WILL NOT CONTINUE REMAINING 
		 // SLEEP TIMING IT WILL GO DIRECTLY INTO WHILE LOOP.

   printf("hai...\n");

   while(1);
}
