#include "header.h"

int main()
{
   signal(1,SIG_IGN);

   printf("hello world pid=%d\n",getpid());
   while(1);
}
