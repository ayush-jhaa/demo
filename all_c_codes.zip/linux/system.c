#include "header.h"

int main()
{
   printf("hai....\n") ;
   system("cal");
   printf("idhar....\n");  
}
