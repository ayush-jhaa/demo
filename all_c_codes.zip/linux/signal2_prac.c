#include"header.h"

int main()
{
   printf("pid=%d\n",getpid());

//   kill(getpid(),SIGFPE);
  
     raise(SIGFPE); // internally calls kill
    while(1);
}
