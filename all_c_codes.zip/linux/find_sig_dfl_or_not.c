#include"header.h"

int main()
{
     void (*p)(int);

     int num;

     printf("enter the  number\n");
     scanf("%d",&num);

     p=signal(num,SIG_IGN);

     if(p==SIG_DFL)
     {
       printf("default signal\n");

     }

     else if(p==SIG_IGN)
     {
	     printf("signal ignore\n");
     }
}
