#include "header.h"
int main()
{
    int x=fork();

    if(x==0)
    {
       printf("in child...\n");
       sleep(5);
       printf("in child after sleep...\n");
       exit(1);
    }

    else
    {
        int s;
	printf("inparent..\n");
	waitpid(x,&s,0);
	printf("in parent after sleep x=%d s=%d\n",x,s);
	while(1);
    }
}
