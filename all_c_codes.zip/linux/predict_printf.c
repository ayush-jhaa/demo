#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

int main()
{
   printf("1st printf\n");
   fork();
   printf("2nd printf\n");
   fork();
   printf("3d printf\n");

   while(1);
}
