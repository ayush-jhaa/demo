#include"header.h"

int main()
{
  printf("hello....\n");
  fork();
  printf("hai.....\n");

}
