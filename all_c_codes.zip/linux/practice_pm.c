#include<stdio.h>
int main()
{
   printf("Hello\n");
   system("ls");
   printf("Hi");
}
