#include"header.h"

void my_isr(int)
{
       printf("in isr\n");
}

int main()
{
   int r;
   printf("hello pid=%d\n",getpid());
   

   signal(14,my_isr);

   r=alarm(10);
   printf("1) r=%d\n",r);
   sleep(3);
   r=alarm(5);
   printf("2) r=%d\n",r);

   while(1);
}
