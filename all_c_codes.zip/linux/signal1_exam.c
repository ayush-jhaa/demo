#include"header.h"

int main()
{
   printf("pid=%d\n",getpid());

   while(1);
}
