#include"header.h"

int n;
void my_isr(int i)
{
	printf("we are in isr\n");
	n--;

	if(n==0)
        raise(9);

	else 
 	  alarm(n);
	

}
int main(int argc,char **argv)
{
    if(argc !=2)
    {
         printf("usage ./a.out num\n");
	 return 0;
    }

     n=atoi(argv[1]);

    alarm(n);
    signal(14,my_isr);

    printf("hai....\n");

    while(1);
}
