#include "header.h"

int main()
{
  int fd,ret;
  char a[10]="\0";

  fd=open("data",O_RDONLY);
  if(fd<0)
  {
     perror("open");
     return 0;
  }

  printf("fd=%d\n",fd);
  ret=read(fd,a,6);
  perror("read");

  printf("ret=%d\n",ret);
  printf("%s",a);
}
