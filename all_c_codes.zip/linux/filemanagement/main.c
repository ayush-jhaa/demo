#include"header.h"

int main()
{

   printf("pid=%d\n",getpid());
   system("ls");
   system("cal");

   while(1);
}
