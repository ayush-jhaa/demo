#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
int main()
{
   int r;
   printf("hello pid=%d\n ",getpid());
   r=fork();
   printf("hai r=%d pid=%d\n",r,getpid());

   while(1);
}
