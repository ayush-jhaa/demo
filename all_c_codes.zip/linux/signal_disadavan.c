#include"header.h"

void my_isr(int n)
{
	printf("in isr n=%d\n",n);
        sleep(5);
	printf("in isr after sleep\n");
}

int main()
{
    printf("hello pid=%d\n",getpid());
    signal(SIGINT,my_isr);

    printf("hai\n");
    while(1);

}
