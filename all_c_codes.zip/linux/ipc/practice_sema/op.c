#include"header.h"

int main()
{
    int id;
    struct sembuf v;

    id=semget(1,5,IPC_CREAT|0644);
    perror("semget");
    printf("id=%d\n",id);

    v.sem_num=2;
    v.sem_op=4;
    v.sem_flg=0;

    printf("BEFORE...\n");
    semop(id,&v,1);
    printf("AFTER...\n");
}
