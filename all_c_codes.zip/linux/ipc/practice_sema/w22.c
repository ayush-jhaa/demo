#include"header.h"

int main()
{
   int fd;
   int id;

   struct sembuf v;

   id=semget(1,5,IPC_CREAT|0664);
   perror("semget");



   fd=open("data",O_WRONLY|O_APPEND|O_CREAT,0664);
   if(fd<0)
   {
     perror("open");
     return 1;
   }

   v.sem_num=3;
   v.sem_op=0;
   v.sem_flg=0;


   printf("started...\n");

   for(char ch='A';ch<='Z';ch++)
   {
      semop(id,&v,1);
      semctl(id,2,SETVAL,1);

      
      write(fd,&ch,1);
      semctl(id,3,SETVAL,1);

      semctl(id,2,SETVAL,0);
      
   }

   printf("done..\n");

}
