#include"header.h"

int main(int argc ,char *argv[])
{
   int id,ret;

   if(argc !=3)
   {
      printf("argument are not correct\n");
      return 1;
   }

   id=semget(1,5,IPC_CREAT|0644);
   perror("semget");
   printf("id=%d\n",id);

   ret=semctl(id,atoi(argv[1]),SETVAL,atoi(argv[2]));
   printf("ret=%d",ret);
}
