//aim:- to create and open semaphone and set and  gt the semaphore value

#include"header.h"

int main(int argc,char *argv[])
{
   int id,r;
   id=semget(4,5,IPC_CREAT|0644);
   if(id<0)
   {
      perror("semget");
      return 0;
   }
   printf("id=%d\n",id);

   //////////////////////////////////////////////////////////////////////

   r=semctl(id,atoi(argv[1]),SETVAL,atoi(argv[2]));

   if(r<0)
   {
     perror("semctl");
     return 0;
   }

   printf("r=%d",r);
}
