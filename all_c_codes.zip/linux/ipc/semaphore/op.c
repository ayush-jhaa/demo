//aim:- to create and open semaphone and set and  gt the semaphore value

#include"header.h"

int main(int argc,char *argv[])
{
   int id,r;
   struct sembuf v;
   id=semget(4,5,IPC_CREAT|0644);
   if(id<0)
   {
      perror("semget");
      return 0;
   }
   printf("id=%d\n",id);

   //////////////////////////////////////////////////////////////////////

   v.sem_num=2;
   v.sem_op=3;
   v.sem_flg=0;

   printf("before...\n");
   semop(id,&v,1);
   printf("after..\n");
}
