#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<stdio_ext.h>
#include<sys/types.h>
#include<time.h>
#include<sys/wait.h>
#include<signal.h>
#include<dirent.h>
#include<fcntl.h>
#include <sys/stat.h>
#include<stdarg.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<sys/sem.h>
#include<sys/shm.h>

