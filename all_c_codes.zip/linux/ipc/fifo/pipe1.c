#include"header.h"

int main()
{
    int p[2];

    pipe(p);
    printf("readend p[0]=%d\n",p[0]);
    printf("writend p[1]=%d\n",p[1]);

    if(fork()==0)
    {
       char s[20];
       printf("in child before read\n");

       read(p[0],s,20);
       printf("in c after read s=%s\n",s);
    }

    else
    {
         char s[20];
	 printf("in parent write\n");
	 fgets(s,20,stdin);
	 write(p[1],s,20);
	 printf("in parent after write \n");
    }
}
