#include"header.h"

int main()
{
    int fdr;
    char a[100];

    mkfifo("fifo_prac",0660);
    
    fdr=open("fifo_prac",O_RDWR);
    
    printf("second..\n");
    scanf("%[^\n]s",a);

    write(fdr,a,sizeof(a));


}
