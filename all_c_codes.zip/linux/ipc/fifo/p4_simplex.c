#include "header.h"

int main()
{
   int fd;

   char str[50];
   char str2[50];



    // reading from other process.

   fd=open("f2_simplex",O_RDONLY);
   printf("reading from other process\n");
   read(fd,str,sizeof(str));
   printf("read  data is=%s",str);


   //writing to other process

   fd=open("f3_simplex",O_WRONLY);
   printf("from f2\n");
   printf("enter the data");
   scanf("%s",str2);
   write(fd,str2,strlen(str2)+1);


}
