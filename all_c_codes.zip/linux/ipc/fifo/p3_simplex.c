#include "header.h"

int main()
{
   int fd;

   char str[50];
   char str2[50];

   mkfifo("f2_simplex",0644);
   mkfifo("f3_simplex",0644);
   perror("mkfifo");

   //writing to other process

   fd=open("f2_simplex",O_WRONLY);
   printf("from f1\n");
   printf("enter the data");
   scanf("%s",str);
   write(fd,str,strlen(str)+1);


    // reading from other process.

   fd=open("f3_simplex",O_RDONLY);
   printf("reading from other process\n");
   read(fd,str2,sizeof(str2));
   printf("read  daTA IS=%s",str2);

}
