#include"header.h"

int main()
{
    int fd;

     perror("mkfifo");

     printf("before open func\n");
     char s[20];

     fd=open("f1",O_RDONLY);
     printf("%d\n",fd);

     printf("after open func\n");


     read(fd,s,sizeof(s));

     printf("DATA=%s\n",s);
}
