#include"header.h"

void *thread_1(void *p)
{
   while(1)
   printf("in thread1...%d",getpid());
}

int main()
{
    pthread_t t1;
    pthread_create(&t1,0,thread_1,0);

    while(1)
    printf("in main...%d\n",getpid());
}
