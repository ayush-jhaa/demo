#include"header.h"

void sort(int *s,int n)
{
    int i,j,temp;

    for(i=0;i<n-1;i++)
    {
       for(j=0;j<n-i-1;j++)
       {
	  if(s[j]>s[j+1])
          {

          temp=s[j];
	  s[j]=s[j+1];
	  s[j+1]=temp;

	  }
       }
    }
}

int main()
{
    int p[2];

    pipe(p);
    printf("readend p[0]=%d\n",p[0]);
    printf("writend p[1]=%d\n",p[1]);

    if(fork()==0)
    {
       int s[5];
       printf("in child before read\n");

       read(p[0],s,sizeof(s));


       printf("in c after read \n");

       sort(s,5);

       for(int i=0;i<5;i++)
       {
         printf("%d ",s[i]);
       }

    }

    else
    {
         int arr[5];

	 for(int i=0;i<5;i++)
	 {
	     printf("enter the %d num\n",i+1);
	     scanf("%d",&arr[i]);
	 }

	 printf("in parent write\n");

	 write(p[1],arr,sizeof(arr));
	 printf("in parent after write \n");
    }
}
