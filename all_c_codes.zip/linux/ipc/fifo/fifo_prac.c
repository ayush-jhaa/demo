#include"header.h"

int main()
{
    int fdr;
    char a[100];

    mkfifo("fifo_prac",0660);
    
    fdr=open("fifo_prac",O_RDWR);
    
    printf("first..\n");

    read(fdr,a,sizeof(a));

    printf("%s",a);
}
