#include "header.h"

struct msgbuf
{
   long mtype;
   char data[30];
};

int main(int argc ,char *argv[])
{
    if(argc !=4)
    {
       printf("Usage:/ key snd message_type message\n");
       return 0;
    }
      struct msgbuf v;
      v.mtype=atoi(argv[2]);
      strcpy(v.data,argv[3]);

      int id;
      id=msgget(atoi(argv[1]),IPC_CREAT|0660);
      if(id<0)
      {
        perror("msgget");
	return 0;
      }

      msgsnd(id,&v,strlen(v.data)+1,0);
      perror("msgsnd");
}
