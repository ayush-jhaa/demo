#include "header.h"

struct msgbuf
{
  long mtype;
  char data[20];
};

int main(int argc,char *argv[])
{
 
   struct msgbuf v;

   v.mtype=atoi(argv[1]);
   strcpy(v.data,argv[2]);
  
   int id;
   id=msgget(1,IPC_CREAT|0660);

   msgsnd(id,&v,strlen(v.data)+1,0); 
}
