#include "header.h"

int main()
{
  int id;
  id=msgget(4,IPC_CREAT|0664);
  int id2;
  id2=msgget(5,IPC_CREAT|0664);


  if(id<0)
  {
     perror("msgget");
    return 0; 
  }
  printf("id=%d\n",id);
}
