#include "header.h"

struct msgbuf
{
  long mtype;
  char data[20];
};

int main(int argc,char **argv)
{
 
   struct msgbuf v;

  
   int id;
   id=msgget(1,IPC_CREAT|0660);

   msgrcv(id,&v,sizeof(v.data),atoi(argv[1]),0); 

   printf("rcv:- %s\n",v.data);
}
