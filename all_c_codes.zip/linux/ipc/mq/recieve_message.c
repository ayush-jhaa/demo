#include"header.h"

struct msgbuf
{
  long mtype;
  char data[30];
};

int main(int argc,char *argv[])
{
   if(argc !=3)
   {
      printf("usage key mstype\n");
      return 0;
   }
   struct msgbuf v;

   int id;

   id=msgget(atoi(argv[1]),IPC_CREAT|0660);
 
   if(id<0)
   {
     perror("msgget");
     return 0;
   }

   msgrcv(id,&v,sizeof(v.data),atoi(argv[2]),0);
   perror("msgrcv");

   printf("data:%s\n",v.data);
}
