#include"header.h"

struct stu
{
   int id;
   char name[20];
   float marks;
};

int main()
{
        int p[2];
	pipe(p);

	if(fork())
	{
	      //parent
	      struct stu v;
	      printf("in parent now give student id name and marks\n");
	      scanf("%d %s %f",&v.id,v.name,&v.marks);

	      write(p[1],&v,sizeof(v));

	}
	else
	{
		struct stu v;
		printf("in child\n");
		read(p[0],&v,sizeof(v));

		printf("%d %s %f",v.id,v.name,v.marks);
	
	}
}
