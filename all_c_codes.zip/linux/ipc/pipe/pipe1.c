#include"header.h"

int main()
{
  int p[2];
  int fd;

  pipe(p);

  if(fork()==0)
  {
      printf("we are in child\n");
      char buff[20];
     fd= read(p[0],buff,sizeof(buff));

      printf("from child..%d \n",fd);
      printf("%s",buff);

  }

  else
  {
       printf("we are in parent..\n");
       char buff[20];
       printf("input from parent...\n");
       fgets(buff,20,stdin);


   fd=    write(p[1],buff,sizeof(buff));
       printf("%d...\n",fd);


  }

  while(1);
}
