#include"header.h"

void convert(char *s)
{
    char temp[20];
    int i=0;
    while(s[i]!='\0')
    {
        if(s[i]>=97 && s[i]<=122)
	{
	   s[i]=s[i]-32;
	}
	i++;
    }
}

int main()
{
     int p[2];
     int q[2];

     pipe(p);
     pipe(q);

    if(fork())
    {
       //parent

	char str[20];
       printf("enter the string\n");
       scanf(" %s",str);

       write(p[1],str,strlen(str)+1);

       read(q[0],str,sizeof(str));

       printf("converted data = %s\n",str);
    }  
    else
    {
      //child 
      char str[20];
      read(p[0],str,sizeof(str));
      convert(str);

      write(q[1],str,strlen(str)+1);

      
    } 
}
