#include"header.h"

int main()
{
   printf("in main code\n");
   printf("hello s1.c pid=%d ppid=%d\n",getpid(),getppid());
   execl("./exec1","execl1","aaaa","bbbb",NULL);

   printf("hai...\n");
   printf("hiiiiiii....\n");
}
