#include"header.h"

void my_isr(int n)
{
    printf("we are  in n=%d\n",n);
}

int main()
{
    printf("in main %d\n",getpid());
    signal(2,my_isr);
    printf("hii...\n");
    while(1);
}
