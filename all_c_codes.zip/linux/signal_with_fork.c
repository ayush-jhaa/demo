#include"header.h"

void my_isr(int n)
{
    printf("IN isr...\n");
    wait(0);
}

int main()
{
   if(fork()==0)
   {
        printf("in child pid=%d\n",getpid());
	sleep(10);
   }

   else
   {
        printf("in parent pid=%d\n",getpid());
        signal(17,my_isr);
	while(1);
   }
}
