#include<stdio.h>

int main()
{
   printf("hello......");
   fflush(stdout);
   while(1);
}
