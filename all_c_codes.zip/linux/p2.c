#include"header.h"
int main()
{
   printf("hello\n");
   system("./p1");
   system("cal");
   printf("Hi...pid=%d\n",getpid());
   while(1);

}
