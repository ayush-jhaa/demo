#include"header.h"

int main()
{
    if(fork()==0)
    {
       printf("we are in if..\n");
       sleep(1);
    }
    else
    {
       printf("we are in else..\n");
       sleep(1);
    }
}
