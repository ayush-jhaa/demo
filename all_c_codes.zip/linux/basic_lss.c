#include"header.h"

int main(int argc,char *argv[])
{
  if(argc !=2)
  {
      printf("usage ./a.out dirname\n");
      return 0;
  }

  DIR *dp;

  struct dirent *p;
  dp=opendir(argv[1]);

      if(dp==0)
      {
         perror("opendir");
         return 0;
      }

      while(p=readdir(dp))
      {
//          if(p->d_name[0]!='.')
                  printf("%s\n",p->d_name);

     } 

      printf("done....\n");
}

