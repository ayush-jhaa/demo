#include<stdio.h>
int main()
{
   printf("linux");
   while(1);
}
