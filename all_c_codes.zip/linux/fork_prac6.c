#include "header.h"

int main()
{
    if(fork()==0)
    {
       sleep(5);
       printf("pid=%d ppid=%d\n",getpid(),getppid());
       
    }
    else
    {
	sleep(2);
        printf("in parent ...pid=%d ppid=%d\n",getpid(),getppid());
	while(1);
    }

    
}
