#include"header.h"

int main()
{
   printf("hello pid=%d\n",getpid());

   if(!fork())
   {
   printf("hello child pid=%d\n",getpid());
   }

   else
   {

       sleep(3);
       printf("in parent again=%d\n",getpid());
       while(1);
   }

}
