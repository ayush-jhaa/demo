#include<stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
   printf("before child process is created\n");
   fork();
   fork();
   fork();
   printf("pid=%d ppid=%d",getpid(),getppid());
}
