#include<stdio.h>
#include<stdlib.h>

void abc(void)
{
   printf("In abc....");
}

int main()
{
   atexit(abc);
   printf("hai");
   sleep(5);
   printf("bye");
   exit(0);
}
