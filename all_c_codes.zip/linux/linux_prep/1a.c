#include"header.h"

int main()
{
    //

    int fr,fw;
    char buff[100];

    fr=open("abc",O_RDWR|0644);
    fw=open("xy",O_RDWR|O_CREAT|0644);

    read(fr,buff,sizeof(buff));
    write(fw,buff,sizeof(buff));

    close(fr);
    close(fw);
}
