#include"header.h"

void my_isr(int n)
{
    printf("we are  in n=%d\n",n);
    signal(n,SIG_DFL);
}

int main()
{
    printf("in main %d\n",getpid());
    signal(2,my_isr);
    printf("hii...\n");
    while(1);
}
