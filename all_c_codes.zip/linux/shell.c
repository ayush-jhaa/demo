#include "header.h"

int main()
{
   char str[20];
   printf("enter the cmd....%d\n",getpid());
   fgets(str,20,stdin);
   fputs(str,stdout);
}
