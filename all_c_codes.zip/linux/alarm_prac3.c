#include"header.h"

int a=6;
void my_isr(int n)
{
     printf("pid of my_isr=%d\n",n);
     
     a=a-2;
        if(a==0)
        exit(0);

   alarm(a);
}

int main()
{
   printf("Hello pid=%d\n",getpid());
   
   signal(SIGALRM,my_isr);
   alarm(2);

   printf("Hai....\n");

   while(1);
}
