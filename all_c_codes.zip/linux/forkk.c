#include<stdio.h>
int main()
{
  printf("pid=%d ppid=%d\n",getpid(),getppid());
  fork();
  fork();
  printf("hi\n");
  while(1);
}
