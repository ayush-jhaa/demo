#include "header.h"

int main()
{
   int ret;

   ret=fork();

   if(ret==0)
   {
     printf("i'm in child %d\n",getpid());
   }
   else 
   {
      usleep(1);
      printf("i'm in parent %d\n",getpid());
      
   }

   while(1);
//   system("clear");  
}
