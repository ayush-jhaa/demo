#include"header.h"

int main( int argc,char* argv[])
{
  printf("%s %s\n",argv[1],argv[2]);
  printf("in signal1.c pid=%d ppid=%d\n",getpid(),getppid());

  while(1);
}

