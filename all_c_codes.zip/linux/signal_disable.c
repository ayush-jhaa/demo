#include"header.h"

void my_isr(int n)
{
	printf("In isr...\n");

     signal(2,SIG_DFL);
     signal(3,SIG_DFL);
}

int main()
{
   printf("pid in main %d\n",getpid());

   signal(2,SIG_IGN);
   signal(3,SIG_IGN);
  
   signal(14,my_isr);

   alarm(10);

   while(1);  
}
