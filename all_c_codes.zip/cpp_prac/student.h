class student
{
   int roll;
   char name[15];
   float marks[6];
   float tmarks;
   float per;
   char grade[3];

        public:

     void input();
     void total_marks();
     void percent();
     void grad();
     void print();


};

