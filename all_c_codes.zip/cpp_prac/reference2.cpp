#include<iostream>
using namespace std;

int main()
{
    int p=10;
    int *q=NULL;
    int * &r=q;
    q=&p;

    cout<<p<<" "<<*q<<" "<<*r<<endl;
    cout<<sizeof(r)<<endl;
}
