#include<iostream>
#include<cstring>
using namespace std;

#include"student.h"
#include"student_detail.cpp"



int main()
{
   student *s=NULL;
   int n;
   cout<<"enter number of students"<<endl;
   cin>>n;

   s=new student[n];

   // now initialize the students data
   for(int i=0;i<n;i++)
   {
      s[i].input();
      s[i].total_marks();
      s[i].percent();
      s[i].grad();

   }

   for(int i=0;i<n;i++)
   {
     cout<<"detail of student"<<i+1<<endl;
     s[i].print();
   }
}
