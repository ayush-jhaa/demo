#include<iostream>
using namespace std;

int main()
{
     int num=1223,r=13;
     int &ref=num;

     cout<<ref<<" "<<&ref<<" "<<num<<" "<<&num<<endl;

     ref=r;
     
     cout<<ref<<" "<<&ref<<" "<<r<<" "<<&r<<endl;
}
