#include<iostream>
#include <cstring>
using namespace std;

void pass_array(int *arr,int n)
{

  for(int i=0;i<n;i++)
  {
    cout<<"write the data"<<endl;
     cin>>arr[i];
  }
}

void print_array(int *arr,int n)
{
    

    for(int i=0;i<n;i++)
    {
       cout<<arr[i]<<" ";
    }
}

int main()
{
    int *arr=NULL;
    int n;
    cout<<"enter the length of arr"<<endl;
    cin>>n;

    arr=new int[n];
    
    pass_array(arr,n);
    print_array(arr,n);

    delete []arr;

}
