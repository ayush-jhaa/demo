#include<iostream>
using namespace std;

class abc
{
    public:

    int a,b;

};

int main()
{
     abc h1;
      h1.a=14;
      h1.b=15;
     cout<<h1.a<<" "<<h1.b<<endl;

     abc h2;

     
     h2.a=28;
     h2.b=30;
     cout<<h2.a<<" "<<h2.b<<endl;
     h1=h2;
     cout<<h1.a<<" "<<h1.b<<endl;

}
