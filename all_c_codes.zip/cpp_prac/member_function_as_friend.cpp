#include<iostream>
using namespace std;
class XYZ;
class ABC
{
	int data1;
	public : 
		ABC()
		{
			data1=0;
		}
		
		void Print()
		{
			cout<<"data1:"<<data1<<endl;
		}
		void SetData1(XYZ &);
};

class XYZ
{
	int data2;
	public :XYZ()
		{
			cout<<"enter the data2:"<<endl;
			cin>>data2;
		}
		void Print()
		{
			cout<<"data2:"<<data2<<endl;
		}
		friend void ABC::SetData1(XYZ &);
};

void ABC :: SetData1(XYZ &x)
{
	data1=~x.data2;
}
int main()
{

	ABC obj;
	XYZ xobj;
	xobj.Print();
	obj.SetData1(xobj);
	obj.Print();
}









