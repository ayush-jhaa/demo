#include<iostream>
using namespace std;

int main()
{
    int *p=NULL;
    p=new int(15);
    cout<<*p;
}
