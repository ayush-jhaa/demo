#include<iostream>
using namespace std;

int &add(int &a,int &b)
{
    static int c;
    c=a+b;
    return c;
}
int main()
{
    int a=15,b=10;
    int &c=add(a,b);

    cout<<c;
}
