
void student:: input(void)
{
   cout<<"enter roll no"<<endl;
   cin>>roll;
   cout<<"enter student name"<<endl;
   cin>>name;
   
   for(int i=0;i<6;i++)
   {
      cout<<"enter subjects marks of student"<<endl;
      cin>>marks[i];
   }


}

void student :: total_marks(void)
{
    tmarks=0;
    for(int i=0;i<6;i++)
    {

      tmarks +=marks[i];
    }
}

void student:: percent(void)
{
     per=(tmarks/6);
}

void student:: grad(void)
{
     if(per<60)
     strcpy(grade,"c");

     else if(per<80)
     strcpy(grade,"b");

     else if(per>=80)
     strcpy(grade,"a");

}

void student:: print(void)
{
     cout<<roll<<endl;
     cout<<name<<endl;
     for(int i=0;i<6;i++)
   {
      cout<<"marks of student"<<endl;
      cout<<marks[i]<<"  ";
   }
     cout<<endl;

     cout<<tmarks<<endl;
     cout<<per<<endl;

     cout<<grade<<endl;



}

