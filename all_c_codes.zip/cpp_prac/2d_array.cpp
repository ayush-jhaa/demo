#include<iostream>
using namespace std;

int main()
{
    int **main=NULL;

    int r,c;
    cout<<"enter rows"<<endl;
    cin>>r;

    cout<<"enter coloumn"<<endl;
       cin>>c;


    main=new int*[r];

    for(int i=0;i<r;i++)
    {

       main[i]=new int[c];

       for(int j=0;j<c;j++)
       {
           cout<<"enter data"<<endl;
	   cin>>main[i][j];
       }
    }


    int i,j;
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			cout<<main[i][j]<<" ";
		}
		cout<<endl;
	}
}
