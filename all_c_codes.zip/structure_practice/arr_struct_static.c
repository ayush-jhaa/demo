#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct
{
     int roll;
     char name[50];
     float mark;

}stu;

stu db[10];
int cnt;

void input(void);
void print(void);
void del(void);
void sort(void);


int main()
{  
   printf("%lu\n",sizeof(*db));
   printf("%lu\n",sizeof(db));

   while(1)
	{
		char choice;
		printf(" input: i\n print: p\n delete: d\n sort: s\n quit: q\n");
		printf("enter your choice:\n");
		__fpurge(stdin);
		scanf("%c",&choice);

		switch(choice)
		{
			case 'i':input();
			       break;

			case 'p':print();
			       break;

			case 'd':del();
			       break;

			case 's':sort();
			       break;

			case 'q':return 0;

			default: printf("invalid input");
		}
	}
	return 0;


}


void input(void)
{
      if(cnt==10)
        {
          printf("not enough space\n");
          return ;
        }

      printf("enter id:");
      scanf("%d",&db[cnt].roll);

      printf("enter name:");
      __fpurge(stdin);
      fgets(db[cnt].name,50,stdin);

      if(db[cnt].name[strlen(db[cnt].name)-1]==10)
          db[cnt].name[strlen(db[cnt].name)-1]=0;

      printf("enter marks:");
      scanf("%f",&db[cnt].mark);

      cnt++;
}


void print(void)
{
  int i=0;

  if(cnt==0)
   {
       printf("data is empty\n");
       return;
   }
    printf("display content:\n");
    for(i=0;i<cnt;i++)
    {
       printf("%d %s %.2f\n",db[i].roll,db[i].name,db[i].mark);
    }
}

void del(void)
{
	int i;
      if(cnt==0)
      {
         printf("data is empty\n");
	 return;
      }
      

      printf("enter the index to delete:");
      scanf("%d",&i);

      if(i>=cnt)
      {
         printf("index not found\n");
         return;
      }

      memmove(db+i,db+i+1,sizeof(stu));
      cnt--;
}

void sort()
{
	stu temp;
	int j,i;
	for(i=cnt-1;i>0;i--)
	{
		for(j=0;j<i;j++)
		{
			if(db[j].roll>db[j+1].roll)
			{
				  
				temp=db[j];
				db[j]=db[j+1];
				db[j+1]=temp;
			}
		}
	}
}
