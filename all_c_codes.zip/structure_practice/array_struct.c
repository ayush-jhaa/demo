#include<stdio.h>
#include<stdlib.h>
typedef struct Student
{
	int roll;
	char *name;
	float mark;
}stu;

void input(stu *p,int n);
void print(stu *p,int n);

char *getstring(void)
{
	char *p=NULL;
    int i=0;
    do
    {
     p=realloc(p,(i+1)*sizeof(char));
     p[i]=getchar();
     
    }while(p[i++] !=10);

	p[i-1]='\0';

    return p;
}
int main()
{
	int n;
	stu arr[3];
	n=sizeof(arr)/sizeof(arr[0]);
	
	input(arr,n);
	print(arr,n);
}

void input(stu *p,int n)
{
      int i=0;

      for(i=0;i<n;i++)
	{
	   printf("enter the roll: ");
	   scanf("%d",&p[i].roll);

	   printf("enter the name: ");
	   __fpurge(stdin);
	   p[i].name=getstring();
	   printf("enter the marks:");
	   scanf("%f",&p[i].mark);

	}
}

void print(stu *p,int n)
{
   int i=0;

   printf("The result are:\n");
   for(i=0;i<n;i++)
   {
	   printf("%d %s %.2f\n",p[i].roll,p[i].name,p[i].mark);
   }
}
