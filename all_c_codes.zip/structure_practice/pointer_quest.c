// input and print

#include<stdio.h>
#include<stdlib.h>
typedef struct 
{
     int roll;
     char *name;
     float mark;

}stu;

int cnt;

char *getstring(void)
{
    char *p=NULL;
    int i=0;
    do
    {
       p=realloc(p,(i+1)*sizeof(char));
       p[i]=getchar();
    }while(p[i++]!=10);

    p[i-1]='\0';

    return p;

}

stu *input(stu *p)
{
   p=realloc(p,(cnt+1)*sizeof(stu));

   printf("enter the roll:");
   scanf("%d",&p[cnt].roll);
   printf("enter the name: ");
   __fpurge(stdin);
   p[cnt].name=getstring();
   printf("enter the marks:");
   scanf("%f",&p[cnt].mark);

   cnt++;

   return p;
}

void print(stu *p)
{
     int i=0;

     for(i=0;i<cnt;i++)
     {
        printf("%d %s %f\n",p[i].roll,(p+i)->name,p[i].mark);
     }
}

int main()
{
     	stu *db=0;
	db=input(db);
	print(db);
	db=input(db);
	print(db);
}
