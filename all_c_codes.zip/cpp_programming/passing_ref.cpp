#include<iostream>
using namespace std;

void passing (int &x,int &y)
{
     x=50;
     y=70;

     
}
int main()
{
    int x=30,y=49;
    
    cout<<x<<y<<endl;
    passing(x,y);
    cout<<x<<y;
}
