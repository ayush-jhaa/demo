abc :: abc()
{
   cout<<"we are in default constructer"<<endl;
   cout<<"enter number of element"<<endl;
   cin>>size;

   ptr= new int[size];

   for(int i=0;i<size;i++)
   {
     cout<<"enter the elements: ";
     cin>>ptr[i];

   }
}

abc :: abc(int *p,int n)
{
    cout<<"we are in parameterized constructer"<<endl;
     size=n;
     ptr=new int[size];

     for(int i=0;i<size;i++)
     {
        ptr[i]=p[i];
     }
}

abc :: abc(abc &obj)
{
    cout<<"we are in copy constructer"<<endl;
    size=obj.size;

    ptr= new int[size];

    for(int i=0;i<size;i++)
    {
        ptr[i]=obj.ptr[i];
    }
}

void abc:: print(void)
{
    for(int i=0;i<size;i++)
    {
       cout<<ptr[i]<<" ";
    }
    cout<<endl;
}

void abc:: sort(void)
{
    int i,j;
    int temp;

    for(i=0;i<size-1;i++)
    {
       for(j=0;j<size-i-1;j++)
       {
          if(ptr[j]>ptr[j+1])
          {
	      temp=ptr[j];
	      ptr[j]=ptr[j+1];
	      ptr[j+1]=temp;
	  }
       }
    }
}

void abc:: search(void)
{
    cout<<"enter the number for search"<<endl;
    int data;
    cin>>data;

    for(int i=0;i<size;i++)
    {
         if(data==ptr[i])
         {
	    cout<<"data found :"<<ptr[i]<<endl;
	    return;
	 }
    }

    cout<<"data not matched"<<endl;
}
