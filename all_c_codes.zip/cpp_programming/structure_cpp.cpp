#include<iostream>
using namespace std;

struct student
{
   private:
   int id;
   char name[20];
   float marks;

   public:
   void input(void)
   {
       
       cout<<"enter id "<<"enter name and enter marks"<<endl;
       cin>>id>>name>>marks;

       if(id<0)
       id= -id;
   }

   void display(void)
   {
       cout<<endl<<id<<" "<<name<<" "<<marks;
   }
};

int main()
{
    student s1;
 //   s1.id=-34;
    s1.input();
    s1.display();
    
    cout<<endl;
    cout<<sizeof(s1);
}
