#include<iostream>
using namespace std;

class Account
{
   int balance;
   static float roi;

	public:
   void setBalance(int b)
   {
       balance=b;

   }

   static void setRoi(float r)
   {
     roi=r;
   }

};

float Account:: roi=3.5;

int main()
{
     Account a1,a2;
     a1.setRoi(4.5);
     Account ::setRoi(4.5);
}
