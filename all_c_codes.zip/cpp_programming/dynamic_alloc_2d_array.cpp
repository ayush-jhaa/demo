#include<iostream>
using namespace std;

int main()
{
    int **matrix=NULL;
    int rows,cols;
    cout<<"enter rows:";
    cin>>rows;
    cout<<"enter cols:";
    cin>>cols;

    matrix= new int* [rows];

    for(int i=0;i<rows;i++)
    {
       matrix[i]=new int[cols];
    }

    // input value in 2d array
    cout<< "enter the element of 2 d array:"<<endl;

    for(int i=0;i<rows;i++)
    {
        for(int j=0;j<cols;j++)
        {
	   cin>>matrix[i][j];
	}
    }

    cout<< "output of the element of 2 d array:"<<endl;

    for(int i=0;i<rows;i++)
    {
        for(int j=0;j<cols;j++)
        {
           cout<<matrix[i][j]<<" ";
        }
	cout<<endl;
    }

}
