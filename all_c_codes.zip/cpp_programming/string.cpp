#include<iostream>
#include<string>
using namespace std;

int main()
{
   string s1;
   cout<<"enter the string"<<endl;
   cin>>s1;
   cout<<s1<<endl;
   cout<<s1.length()<<endl;
   cout<<sizeof(s1)<<endl;

}
