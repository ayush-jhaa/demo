#include<iostream>
using namespace std;

class Complex 
{
    int real,img;
    public:

    void input(void)
    {
        cout<<"enter real part:"<<endl;
	cin>>real;
	cout<<"enter imaginary part:"<<endl;
 	cin>>img;
    }

    void print(void)
    {
        cout<<real;
	if(img>=0)
	cout<<"+";
	cout<<img<<"i"<<endl;
    }

    Complex add(Complex obj)
    {
        Complex temp;
	temp.real=real+obj.real;
	temp.img=img+obj.img;

	return temp;
    } 

};

int main()
{

    Complex e1,e2,e3,e4;
    e1.input();
    e2.input();
    cout<<"e1"<<endl;
    e1.print();
    cout<<"e2"<<endl;
    e2.print();
    e3=e1.add(e2);

    cout<<"e3"<<endl;
    e3.print();

}
