#include<iostream>
using namespace std;

class matrix
{
     int a[2][2];

    public:
     void Input()
     {
        for(int i=0;i<2;i++)
	{
	   for(int j=0;j<2;j++)
	     cin>>a[i][j];
	}
     }

     void print()
     {
        for(int i=0;i<2;i++)
        {
	   for(int j=0;j<2;j++)
	     cout<<a[i][j]<<" ";
	     
	}
	    cout<<endl;
     }

     matrix & add(matrix &m)
     {
         static matrix temp;
	   for(int i=0;i<2;i++)
	   {
	     for(int j=0;j<2;j++)
	     temp.a[i][j]=a[i][j]+m.a[i][j];
	   }

	   return temp;
     }

     matrix & sub(matrix &m)
     {
         static matrix temp;
           for(int i=0;i<2;i++)
           {
             for(int j=0;j<2;j++)
             temp.a[i][j]=a[i][j]-m.a[i][j];
           }

           return temp;
     }

};

int main()
{
   matrix m1,m2,m3,m4;
   m1.Input();
   m2.Input();
   m3=m1.add(m2);
   m4=m2.sub(m3);
   cout<<"m1"<<endl;
   m1.print();
   cout<<"m2"<<endl;
   m2.print();
   cout<<"m3"<<endl;
   m3.print();
   cout<<"m4"<<endl;
   m4.print();
}

