#include<iostream>
using namespace std;

#include"exam_prep_header.h"
#include"exam_prep_constructers.cpp"

int main()
{
  int q[5]={34,12,45,10,4};

  abc obj1;          // default constructer
  cout<<"obj1"<<endl;
  obj1.print();

  abc obj2=obj1;    // copy constructer
  cout<<"obj2"<<endl;
  obj2.print();
  obj2.sort();
  cout<<"obj2 after sorting"<<endl;
  obj2.print();

  abc obj3(q,5);    // parameterized constructer
  cout<<"obj3:"<<endl;
  obj3.print();
  obj3.search();
  

    
}
