#include<iostream>
#include<unistd.h>
#include<cstdlib>

using namespace std;

int main()
{
	int num,guessnumber,cnt=0;
	char ch;
	do
	{
		cnt=0;
	srand(getpid());
	num=rand()%100;
	while(1)
	{
	cout<<"Guess the num:"<<endl;
	cin>>guessnumber;
	cnt++;
	if(num>guessnumber)
	{
		cout<<"Your Guess is too small!!!:"<<endl;
	}
	else if(num<guessnumber)
	{
		cout<<"Your Guess is too large !!!"<<endl;
	}
	else
	{
		cout<<"Wow Ur Guess is matched !!!:"<<endl;
		cout<<"U took :"<<cnt<<" Guesses"<<endl;
		break;
	}
	if(cnt==5)
	{
cout<<"You Lost the game, Better Luck next time:"<<endl;
	break;
	}
	sleep(1);
	system("clear");
	}
	cout<<"enter S to play another game:"<<endl;
	cin>>ch;
	}while(ch=='S');
}

