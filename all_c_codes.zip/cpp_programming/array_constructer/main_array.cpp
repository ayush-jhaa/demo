#include<iostream>
using namespace std;

#include "array.h"
#include "array.cpp"

int main()
{
    array obj1;
    cout<<"obj1:"<<endl;
    obj1.print();
 
    array obj2=obj1;
    cout<<"obj2"<<endl;
    obj2.print();

    cout<<"sort obj2"<<endl;
    obj2.sort();
    obj2.print();
    
    cout<<"let's see obj1"<<endl;
    obj1.print();
}
