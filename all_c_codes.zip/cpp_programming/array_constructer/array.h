class array
{
   private:
   int *ptr;
   int size;

   public:
   array();
   array(int *,int);
   array(array &);
   void print();
//   void search();
   void reverse();
   void sort();

  ~array();

};
