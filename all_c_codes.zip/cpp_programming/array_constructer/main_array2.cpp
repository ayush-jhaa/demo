#include<iostream>
using namespace std;

#include"array.h"
#include"array.cpp"

void f1();
int main()
{
	for(int i=0;i<3;i++)
	{
		f1();
	}


}

void f1()
{
	array obj1;
	obj1.print();
}

