array :: array()
{
   cout<<"we are in default constructer"<<endl;
   cout<<"enter the number of element"<<endl;
   cin>>size;
   ptr=new int[size];

   for(int i=0;i<size;i++)
   {
      cout<<"enter the elements"<<endl;
      cin>>ptr[i];
   }
}

array :: array(int *q,int s)
{
    cout<<"we are in parameterized constructer"<<endl;
    size=s;

    ptr= new int[size];
    for(int  i=0;i<size;i++)
    {
       ptr[i]=q[i];
    }
    
}

array :: array(array &obj)
{
    cout<<"we are in copy constructer"<<endl;
    size=obj.size;
    ptr=new int[size];

    for(int i=0;i<size;i++)
    {
       ptr[i]=obj.ptr[i];
    }
}

void array :: print(void)
{
    for(int i=0;i<size;i++)
    {
       cout<<ptr[i]<<" ";
    }
    cout<<endl;
}

void array :: sort(void)
{
    int temp;
    int i,j;

    for( i=0;i<size-1;i++)
    {
       for( j=0;j<size-i-1;j++)
	{
	    if(ptr[j]>ptr[j+1])
	    {
	       temp=ptr[j];
	       ptr[j]=ptr[j+1];
	       ptr[j+1]=temp;
	    }
	}
    }
}

void array :: reverse(void)
{
   int temp;
   int i,j;

   for( i=0, j=size-1;i<j;i++,j--)
   {
        temp=ptr[i];
	ptr[i]=ptr[j];
	ptr[j]=temp;
   }
}

array :: ~array()
{
    delete[]ptr;
    cout<<"in destructer"<<endl;
}
