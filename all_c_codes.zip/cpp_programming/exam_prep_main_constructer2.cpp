#include<iostream>
using namespace std;


#include"exam_prep_header.h"
#include"exam_prep_constructers.cpp"

void f1();
int main()
{
	for(int i=0;i<3;i++)
	{
		f1();
	}


}

void f1()
{
	abc obj1;
	obj1.print();
}
