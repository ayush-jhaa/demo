#include<iostream>
using namespace std;

int add(int a=0,int b=0,int c=0,int d=0)
{
    return a+b+c+d;
}
int main()
{
     int a=30,b=50,c=23,d=60;

     cout<<add(a,b)<<endl;
     cout<<add(a,b,c,d);
}
