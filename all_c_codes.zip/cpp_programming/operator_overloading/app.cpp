#include<iostream>
using namespace std;

#include"complex.h"
#include"complex.cpp"

int main()
{
	Complex e1(34,56),e2(67,89),e3,e4;
	e3=e1+e2;
	e4=e1-e2;

	cout<<"e1:";
	e1.Print();
	cout<<"e2:";
	e2.Print();
	cout<<"e3:";
	e3.Print();
	cout<<"e4:";
	e4.Print();
}


