Complex :: Complex(int a,int b)
{
	real=a;
	img=b;
}

void Complex :: Print()
{
	cout<<real;
	if(img>=0)
		cout<<"+";
	cout<<img<<"i"<<endl;
}

Complex  Complex :: operator+(Complex &obj)
{
	static Complex temp;
	temp.real=real+obj.real;
	temp.img=img+obj.img;
	return temp;
}

Complex  Complex :: operator-(Complex &obj)
{
	static Complex temp;
	temp.real=real-obj.real;
	temp.img=img-obj.img;
	return temp;
}

Complex :: ~Complex()
{

	cout<<"Complex Destructor:"<<endl;
}



Complex  Complex :: operator+(int x)
{
	static Complex temp;
	temp.real=real+x;
	temp.img=img;
	return temp;
}

Complex  Complex :: operator++()
{
	++real;
	++img;
	return *this; // returning calling object
}

Complex  Complex :: operator++(int)
{
	static Complex temp;
	temp.real=real++;
	temp.img=img++;
	return temp;
}


















