#include<iostream>
using namespace std;

int main()
{
    int *ptr=NULL;
    ptr=new int[5];

    int *org_pointer=ptr;

    for(int i=0;i<5;i++)
    {
        cin>>*ptr;
	ptr++;
    }

    ptr=org_pointer;

    for(int i=0;i<5;i++)
    {
        cout<<*ptr<<" ";
	ptr++;
    }
}
