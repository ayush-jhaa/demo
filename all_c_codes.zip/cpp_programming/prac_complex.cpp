#include<iostream>
using namespace std;

class abc
{
    int real;
    int img;

    public:

    void setdata(void);
    void print(void);
    abc add(abc);
    abc sub(abc);
};

void abc:: setdata(void)
{
      cout<<"enter real value: ";
      cin>>real;

      cout<<"enter img value: ";
      cin>>img;
}

void abc:: print(void)
{
    cout<<real;

    if(img>=0)
	    cout<<"+";
    cout<<img<<"i"<<endl;

}

abc abc:: add(abc e)
{
   abc temp;

   temp.real=real+e.real;
   temp.img=img+e.img;

   return temp;
}

abc abc:: sub(abc e)
{
   abc temp;

   temp.real=real-e.real;
   temp.img=img-e.img;

   return temp;
}


int main()
{
    abc obj1;
    obj1.setdata();
    
    abc obj2;
    obj2.setdata();

    cout<<"obj1: ";
    obj1.print();

    cout<<"obj2: ";
    obj2.print();

    abc obj3;
    obj3=obj1.add(obj2);

    cout<<"obj3: ";
    obj3.print();

    abc obj4;
    obj4=obj1.sub(obj2);

    cout<<"obj4: ";
    obj4.print();
}
