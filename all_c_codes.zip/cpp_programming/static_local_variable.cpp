#include<iostream>
using namespace std;
 
void fnc( ) 
{
  static int x;
  int y;

}

class Account
{
   private:
   int balance;       //instance member variable 
   static float roi;  // static member variable // class variable
   
   public:
    void setbalance(int b)
    {
       balance=b;
    }
};

float Account :: roi=3.5f;   //memory will come now

int main() 
{
      Account a1;
}

