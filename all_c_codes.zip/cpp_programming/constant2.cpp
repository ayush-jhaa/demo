#include<iostream>
using namespace  std;

class family
{
  const  int cash;               
  const  int gold;

	public:

     family(): cash(34) ,gold(54)
     {  }

/*    void set_data()
    {
        cout<<"enter cash:"<<endl;
	cin>>cash;
	cout<<"enter gold:"<<endl;
	cin>>gold;
    }
*/
    void get_data(void) const
    {
//	 cash=100;
//       gold=10;
         cout<<"cash is "<<cash<<" and gold is "<<gold<<endl;
    }
};

int main()
{
     family f1;     
//   f1.set_data();
     f1.get_data();
}
