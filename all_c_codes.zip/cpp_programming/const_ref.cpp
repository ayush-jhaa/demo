#include<iostream>
using namespace std;

int main()
{	
    int &ref=10;
	cout<<ref<<endl;
	const int y=123;
	const int &r=y;
	cout<<r<<endl;
}

