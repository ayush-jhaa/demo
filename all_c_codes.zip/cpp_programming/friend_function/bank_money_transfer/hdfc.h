class hdfc
{
   int accno;
   char name[20];
   float balance;

	public: hdfc();
		void deposit(float);
		void balenq();
		bool withdrawal(float );
		bool transaction(sbi & );

//		friend bool sbi:: transaction(hdfc);
		friend class sbi;		

};
