hdfc:: hdfc()
{
    cout<<"hdfc customer"<<endl;
    cout<<"enter account number"<<endl;
    cin>>accno;
    cout<<"enter name"<<endl;
    cin>>name;
    cout<<"enter the amount"<<endl;
    cin>>balance;

}


void hdfc::deposit(float amt)
{
   balance=balance+amt;
}

bool hdfc:: withdrawal(float amt)
{
  if(amt<=balance)
   {
   balance=balance-amt;
   return true;
   }

  else
  return false;
}

void hdfc:: balenq(void)
{
    cout<<"your hdfc balance remains "<<balance<<" rupees"<<endl;
}

bool hdfc:: transaction(sbi & obj)
{
    float amt;
    cout<<"enter the amount to give to sbi friend"<<endl;
    cin>>amt;

    if(amt<=balance)
    {
       balance -=amt;
       obj.balance +=amt;
       return true;
    }
    return false;
}
