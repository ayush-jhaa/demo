class sbi
{
   int accno;
   char name[20];
   float balance;

	public: sbi();
		void deposit(float);
		void balenq();
		bool withdrawal(float );
		bool transaction(hdfc );
		friend bool hdfc:: transaction(sbi &);
};
