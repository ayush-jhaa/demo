sbi:: sbi()
{
    cout<<"sbi customer"<<endl;
    cout<<"enter account number"<<endl;
    cin>>accno;
    cout<<"enter name"<<endl;
    cin>>name;
    cout<<"enter the amount"<<endl;
    cin>>balance;

}


void sbi::deposit(float amt)
{
   balance=balance+amt;
}

bool sbi:: withdrawal(float amt)
{
  if(amt<=balance)
   {
   balance=balance-amt;
   return true;
   }

  else
  return false;
}

void sbi:: balenq(void)
{
    cout<<"your sbi balance remains "<<balance<<" rupees"<<endl;
}

bool sbi:: transaction(hdfc obj)
{
    float amt;
    cout<<"enter the amount to give to sbi friend"<<endl;
    cin>>amt;

    if(amt<=balance)
    {
       obj.balance +=amt;
       balance -=amt;
       return true;
    }
    return false;
}
