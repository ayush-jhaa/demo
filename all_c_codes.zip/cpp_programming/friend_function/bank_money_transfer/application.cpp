#include<iostream>
using namespace std;
class sbi;
#include"hdfc.h"

#include"sbi.h"
#include"hdfc.cpp"


#include"sbi.cpp"


int main()
{
   cout<<"from hdfc user"<<endl;
   hdfc myacc;

   cout<<"deposit the amount to your bank"<<endl;
   cout<<"enter amount"<<endl;
   float amt;
   cin>>amt;
   myacc.deposit(amt);
   myacc.balenq();

   cout<<"withdraw some amount"<<endl;
   cin>>amt;
   myacc.withdrawal(amt);
   myacc.balenq();

   sbi frienacc;
   cout<<"give money to sbi friend"<<endl;

   if(myacc.transaction(frienacc ))
   {
     cout<<"transaction completed"<<endl;

   }
   else
   {
      cout<<"transaction failed due to insufficient fund"<<endl;
   }
   cout<<"my balance"<<endl;
   myacc.balenq();
   cout<<"friend balance"<<endl;
   frienacc.balenq();


