#include<iostream>

using namespace std;
class square;


class rectangle
{
    float length,breadth,area,peri;

        public: rectangle()
                {
                    cout<<"enter rect length"<<endl;
                    cin>>length;
		    cout<<"enter rect breadth"<<endl;
		    cin>>breadth;
                }

                void calarea(void)
                {
                    area=length*breadth;
                }
                void calperi(void)
                {
                    peri=2*(length+breadth);
                }
		friend void print(square,rectangle);
};

class square
{
    float side,area,peri;

	public: square()
		{
		    cout<<"enter square side"<<endl;
		    cin>>side;
		}

		void calarea(void)
		{
		    area=side*side;
		}
		void calperi(void)
		{
		    peri=4*side;
		}

		friend void print(square,rectangle);

};

void print(square s,rectangle r)
{
     cout<<"Rectangle details:"<<endl;
	cout<<"len:"<<r.length<<endl;
	cout<<"bre:"<<r.breadth<<endl;
	cout<<"area:"<<r.area<<endl;
	cout<<"peri:"<<r.peri<<endl;
	
	cout<<"Square details:"<<endl;
	cout<<"side:"<<s.side<<endl;
	cout<<"area:"<<s.area<<endl;
	cout<<"peri:"<<s.peri<<endl;

}

int main()
{
    square sobj;
    sobj.calarea();
    sobj.calperi();

    rectangle robj;
    robj.calarea();
    robj.calperi();

    print(sobj,robj);
}
