class abc
{
   int *ptr=NULL;
   int size;

   public:
    
   abc();
   abc(int *,int);
   abc(abc &);
   void print();
   void sort();
   void search();
//   ~abc();

};
