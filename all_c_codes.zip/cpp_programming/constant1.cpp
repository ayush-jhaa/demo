#include<iostream>
using namespace  std;

class family
{
  mutable  int cash;               // if member are constant must intialize data member through constructer.
  mutable  int gold;

	public:
    void set_data()
    {
        cout<<"enter cash:"<<endl;
	cin>>cash;
	cout<<"enter gold:"<<endl;
	cin>>gold;
    }

    void get_data(void) const
    {
	 cash=100;
	 gold=10;
         cout<<"cash is "<<cash<<" and gold is "<<gold<<endl;
    }
};

int main()
{
     family f1;     // whenever going for constant object must go for user defined constructer.
     f1.set_data();
     f1.get_data();
}
