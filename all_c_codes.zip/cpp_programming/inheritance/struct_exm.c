#include<stdio.h>

struct stu
{
   int a;
};

struct ptu
{
   int a;
};

int main()
{
     struct ptu v;	
     struct stu *p=&v;

     scanf("%d",&p->a);

     
     printf("%d",p->a);
}
