#include<iostream>
using namespace std;

int main()
{
    int x;
    cin>>x;
    int &r=x;

    r=20;

    cout<<r;
}
