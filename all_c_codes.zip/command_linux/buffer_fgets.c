#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*int main()
{
   char str[4];
   char s1;
   gets(str);   

  printf("enter char: ");
  printf("\n");
  scanf("%c",&s1);
 
   printf("%s %c",str,s1);
}
*/

int main()
{
    char str[5];
    fgets(str,5,stdin);

    printf("%s",str);
    int n=strlen(str);
    printf("strlen:%d",n);
    
}
