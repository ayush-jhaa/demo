#include "myheader.h"

void printnode(STUDENT *head) {
    int cnt;
    STUDENT *temp;
    
    printf("Enter the node to print: ");
    scanf("%d", &cnt);

    temp = head;  

    if (temp != NULL) {
        while (cnt > 1 && temp != NULL) {
            temp = temp->link;
            cnt--;
        }

        if (temp != NULL) {
            printf("%d %s", temp->roll, temp->name);
        } else {
            printf("Node not found.\n");
        }
    } else {
        printf("List is empty.\n");
    }
}

