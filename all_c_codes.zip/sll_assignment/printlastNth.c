#include"myheader.h"

int findlength(STUDENT *ptr)
{
    int length=0;

    while(ptr!=NULL)
    {
         length++;
	 ptr=ptr->link;
    }
    return length;

}

void printfromlast(STUDENT *head)
{
    STUDENT *temp=head;
    STUDENT *temp1=head;

    int l=findlength(temp1);
    int n,cnt;

    printf("enter the node: ");
    scanf("%d",&n);

    if(head==NULL)
       printf("list is empty\n");

    
    else if(n>l) 
    printf("list is smaller than required node\n");

    else
    {
	   cnt=l-n+1;
           while (cnt > 1) {
            temp = temp->link;
            cnt--;
        }
            printf("%d %s", temp->roll, temp->name);
    }

}
