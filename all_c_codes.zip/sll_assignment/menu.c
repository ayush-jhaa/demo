/* Write a program to implement the following functionalites on a Singly Linked List.
	a. Add()------> adding nodes to linked list.
	b. Print()-----> prints the information of nodes.
	c. PrintPrime()-----> print the information of those nodes whose roll no is a primeno.
	d. Printnthnode()---->prints the nth Node Information.
	e. Del_all()----------->should delete all nodes in the linked list.
	f. printnthfromlast()--------------> should print the nth node from the end of the linked
	   list.
*/

#include "myheader.h"

int main()
{
     STUDENT *head=NULL;
     char choice;

     while(1)
     {
        printf("a.ADD p.PRINT c.print prime n.print_nth_node l.print nth from last d.DELETE_ALL Q.QUIT\n");
	printf("enter your choice :");
	__fpurge(stdin);
	scanf("%c",&choice);

	switch(choice)
	{
	
	    case 'a': head=Add(head);
		      break;
	    case 'd': head=DeleteAll(head);
		      break;
	    case 'p': print(head);
		      break;
	    case 'c': printprime(head);
		      break;
	    case 'n': printnode(head);
		      break;
	    case 'l': printfromlast(head);
		      break;
	    case 'q': return 0;
	}
	
     
     }
         
}
