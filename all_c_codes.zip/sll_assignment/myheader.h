#include<stdio.h>
#include<stdlib.h>

typedef struct Student
{
   int roll;
   char name[20];
   struct Student *link;
}STUDENT;

STUDENT *Add(STUDENT *);
STUDENT *DeleteAll(STUDENT *);
void print(STUDENT *);
void printprime(STUDENT *);
void printnode(STUDENT *);
void printfromlast(STUDENT *);

