#include "myheader.h"

int  isprime(int num)
{
     int i;

     for(i=2;i<num;i++)
     {
         if(num%i==0)
         {
	     return 0;
	 }

     }
     return 1;
}

void printprime(STUDENT *ptr)
{
	if(ptr==NULL)
        printf("list is empty\n");

	else
	{
	    while(ptr)
	    {
		if(isprime(ptr->roll))
		{
			printf("%d %s\n",ptr->roll,ptr->name);
	               ptr=ptr->link;
		}
		else
		ptr=ptr->link;
	    }
	}

}
