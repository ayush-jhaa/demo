#include "myheader.h"

void print(STUDENT *ptr)
{
	if(ptr==NULL)
	printf("list is empty");

	else
	{
	 	while(ptr)
		{
		  printf("%d %s\n",ptr->roll,ptr->name);
	  	  ptr=ptr->link;
	       	}

	}
}
