#include "myheader.h"

STUDENT *DeleteAll(STUDENT *head)
{
     STUDENT *temp;
     if(head==NULL)
     {
       printf("list is empty");

     }
     else
     {
         while(head)
         {
	    temp=head;
	    head=head->link;
	    free(temp);
	 }
     }
     return head;
}

