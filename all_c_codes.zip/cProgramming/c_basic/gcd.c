#include<stdio.h>

int main(){

	int n,m,actualVal;
	printf("enter two numbers");
	scanf("%d %d",&n,&m);

	int temp,store;

       for(int i=1;i<=n/2;i++){
       
	       if(n%i==0){
	       
		        temp=i;
	       }
	       for (int j=1;j<=m/2;j++){
	 
		       if(m%j==0){
		       
			        store=j;

			       if(store==temp){
			       
				       actualVal=store;
			       }
		       }
	       }
       }

       printf("%d is gcd of two",actualVal);

       return 0;
}
