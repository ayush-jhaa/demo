#include<stdio.h>
int larg(int a)
{

	int temp=-1,val,flag=1;
	while(a>0)
         {
	 
		 val=a%10;
		 if(val>=temp)
		   {
		   
		     temp=val;
		     flag=1;
		   }
		 else
	          {
		  
			  flag=0;
			  break;;
		  }
	 }
	return flag;
}

int small(int b)
{
          int tem=111,value,flag=1;

	  while(b>0)
	   {
	         value=b%10;
		 if(value>=tem)
	         {
		 
			 tem=value;
			 flag=1;
		 }
		 else
	         {
		 
			 flag=0;
			 break;
		 }
	   }
	  return flag;

}
int main()
{

	int n;
	printf("enter the number :"); scanf("%d",&n);
        int y=larg(n);
	int x=small(n);

	if(x)
	printf("sorted");

	else if(y)
	printf("sorted");

	else
	printf("not sorted");
}
