#include<stdio.h>

int main()
{

	int n,rem,sum=0,power=1,store;
	printf("enter the binary data :");
	scanf("%d",&n);
	unsigned int new=n;

	while(n>0)
	{
		rem=n%10;
		store=rem*power;
		sum=sum+store;
		power *=2;
		n /=10;

	

	}
	printf("The binary equivalent  %d decimal is %d",new,sum);
}
