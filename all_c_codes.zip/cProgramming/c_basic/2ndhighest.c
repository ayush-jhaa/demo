#include <stdio.h>

int main() {
    int num, highest = -1, secondHighest = -1;

    printf("Enter an integer: ");
    scanf("%d", &num);

    while (num > 0) {
        int digit = num % 10;

        if (digit > highest) {
            secondHighest = highest;
            highest = digit;
        } else if ( digit > secondHighest) {
            secondHighest = digit;
        }

        num /= 10;
    }

    if (secondHighest != -1) {
        printf("Second highest digit: %d\n", secondHighest);
    } else {
        printf("There is no second highest digit.\n");
    }

    return 0;
}

