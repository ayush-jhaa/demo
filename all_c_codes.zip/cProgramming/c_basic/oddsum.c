#include<stdio.h>
int main()
{

	int data,sum=0,lastdigit;
	scanf("%d",&data);

	for(;data>0;data=data/10)
	{
	
		lastdigit=data%10;
                if(lastdigit%2 ==1)
		{
                   sum=sum+lastdigit;
		}
	}
	printf("%d",sum);
}
