#include<stdio.h>

int main(){

	int n,rem,sum;
	printf("enter than number : ");
	scanf("%d",&n);
	int temp=n;

	while (n>0){
		rem=n%10;
		sum=sum*10+rem;
		n=n/10;


	}
	if(temp==sum){

		printf("%d is pallindrome",temp);

	}	else {

		printf("%d is not a pallindrome",temp);
	}
	return 0;
}
