#include <stdio.h>

int main() {
    int n;
    printf("enter the number:");
    scanf("%d", &n);

    int largest_prime_factor = 1;

    // Find the smallest prime factor and divide n by it until n becomes 1
    for (int i = 2; i <= n; i++) {
        while (n % i == 0) {
            largest_prime_factor = i;
            n /= i;
        }
    }

    printf("%d\n", largest_prime_factor);
    return 0;
}

