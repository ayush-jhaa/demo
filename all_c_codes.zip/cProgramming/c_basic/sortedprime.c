#include<stdio.h>
int isprime(int n)
{
	int i,count=0;
	for(i=1;i<=n;i++)
	{
	
		if(n%i ==0)
		{
			count++;
		}

	}
	if (count==2)
	return 1;
	else
	return 0;


}
int smallerPrime(int n)
{

	int rem,flag=1,val=1111;

	while(n>0)
	{
	
		rem=n%10;
		if(rem<=val)
		{
		   val=rem;
		   flag=1;
		}
		else
		{
		
			flag=0;
			break;
		}
		n=n/10;
	}
	return flag;

}

int largerPrime(int n)
{

        int rem,flag=1,val=-1;
	int p=n;

        while(n>0)
        {

                rem=n%10;
                if(rem>=val)
                {
                   val=rem;
                   flag=1;
                }
                else
                {

                        flag=0;
                        break;
                }
		n=n/10;


        }
	return flag;
	
	

}
int main()
{

	int n;
	scanf("%d",&n);

	int x=smallerPrime(n);
	int y=largerPrime(n);
	int p= isprime(n);

	if(x && p)
	printf("sorted prime");
	else if(y && p)
	printf("sorted prime");
	else
	printf("not sorted");
}
