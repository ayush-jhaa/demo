#include <stdio.h>

int main() {

    int n, i, j, count, sum = 0;

    printf("Enter the limit:\n");
    scanf("%d", &n);

    for (i = 2; i <= n; i++) {

        count = 0;

        for (j = 2; j <= i; j++) {

            if (i % j == 0) {
                count++;
            }
        }

        if (count == 1) {
            sum += i;
        }
    }

    printf("The sum of prime numbers up to %d is: %d\n", n, sum);

    return 0;
}
