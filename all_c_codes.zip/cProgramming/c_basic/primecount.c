#include<stdio.h>
int main()
{
       int n,i,j,c;
       scanf("%d",&n);

       for(i=50,c=0;c<n;i++)
	   {
	   
		   for(j=2;j<i;j++)
		     {
		     
			     if(i%j==0)
			      {
			      
				      break;
			      }
		     }
		   if(i==j)
		    {
		    
			    printf("%d is prime\n",i);
			    ++c;
		    }
	   }
}
