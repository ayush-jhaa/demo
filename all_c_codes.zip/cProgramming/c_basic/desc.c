#include<stdio.h>
int main()
{

	int data,val,des=-1,flag=1;
	scanf("%d",&data);

	for(;data>0;data /=10)
	{
	      val=data%10;
	      if(val>=des)
		{
		
			des=val;
			flag=1;
		}
	      else
		{
		
			flag=0;
			break;
		}
	      
	}
	if(flag==0)
		printf("not descending");
	else if(flag==1)
		printf("descending");
}
