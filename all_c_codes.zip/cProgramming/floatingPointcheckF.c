#include<stdio.h>

int main(){

	float n=65.000;
	float r;

	r=n/0;

	printf("%f",r);
}
