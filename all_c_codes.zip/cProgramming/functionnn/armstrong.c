#include<stdio.h>

void armstrong(int n){

	int temp=n;
	int rem,sum=0;
	while(n>0){
	
		rem=n%10;
		sum=sum+rem*rem*rem;
		n=n/10;
		
	}
	if(sum==temp){
	
		printf("number is armstrong number :%d",temp);
	}
	else{
	
		printf("number is not an armstrong number: %d",temp);
	}
}

int main(){

	int n;
	printf("enter the number: ");
	scanf("%d",&n);

	armstrong(n);

	return 0;

}
