#include<stdio.h>
int testBit(int,int);
void printBinary(int var)
{
       
       int bit=31;

       for(bit;bit>=0;bit--)
	  {
	  
		  printf("%d",(var>>bit)&1);
	  }
       printf("\n");
}

int reverse(int data)
{

	int left,right;
	for(left=31,right=0;left>right;left--,right++)
	{
	
		if(testBit(data,left) != testBit(data,right))
		{
		
			data=data^(1<<left);
			data=data^(1<<right);
		}
	}
	return data;

}
int testBit(int data,int bit)
{

	return (data>>bit)&1;
}

int main()
{

	int data;
	printf("enter the data :\n"); scanf("%d",&data);

	printBinary(data);
	int y=reverse(data);

	printf("%d\n",y);
	printBinary(y);


}
