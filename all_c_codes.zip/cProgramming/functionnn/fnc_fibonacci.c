#include<stdio.h>

void fibon(int n){

	int next;
	int s1=0,s2=1;

	for(int i=0;i<n;i++){
	
		if(i<=1){
		next=i;
		printf(" %d ",next);
		}

		next=s1+s2;
		s1=s2;
		s2=next;
		printf(" %d ",next);
	}
}

int main(){

	int count;
	printf("enter the number :" );
	scanf("%d",&count);

		fibon(count);
	return 0;
}
