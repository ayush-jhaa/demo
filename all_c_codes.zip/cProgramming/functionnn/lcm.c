#include<stdio.h>

int gcd(int x,int y)
{

	int temp;
	while(y != 0)
	{
	  temp=y;
	  y=x%y;
	  x=temp;

	}
	return x;
}

int lcm(int a,int b)
{

	return a*b/gcd(a,b);
}

int main()
{

	int a,b;
	printf(" enter two value :");
	scanf("%d %d",&a,&b);

	int y= lcm(a,b);

	printf("lcm of %d and %d is: %d",a,b,y);
}
