#include<stdio.h>

int descend(int n){

	int s1=n%10;
	int flag=0;
	n=n/10;

	while(n>0){
	
	int s2=n%10;
		if (s1>s2){
		
			flag=1;
		}
	 s1=s2;
                n=n/10;
	}
	if (flag==0){
	
		return 1;
	}
	else return 0;
}

int main(){

	int n;
	printf("enter the number :");
	scanf("%d",&n);

	if(descend(n)){
		printf("number is descending");
	}
	else{
	
		printf("not descending");
	}
	return 0;

}
