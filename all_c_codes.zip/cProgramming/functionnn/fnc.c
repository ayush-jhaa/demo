#include<stdio.h>
#include<stdlib.h>
void eng(){

	printf("we are in england\n");
	exit(0);
}
void aus(){

	printf("we are in australia\n ");
	eng();
}
void india(){

	printf("we are in india\n");
	aus();
}
int main1()
{
 printf("we are in main\n");
 india();
 exit(0);

}
