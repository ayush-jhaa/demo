#include<stdio.h>

//void prime(int n) // void case
int prime(int n){
	int flag=0;

	int m=n/2;

	for (int i=2;i<=m;i++){
	
		if(n%i==0){
		
			flag=flag+1;
		}
	}
	if(flag==0){
	
		return 1;

		//printf("number is prime number"); // void case

	}
	else { 
		return 0;
		
		//printf("number is not a prime number"); // void case

	}
}

int main(){

	int numb;
	printf("enter any number :");
	scanf("%d",&numb);

//	prime(numb);     // this is case of void

	if(prime(numb)){
	printf("number is prime number");

	}

	else
	{
	printf("number is not prime number");


	}
	return 0;
}
