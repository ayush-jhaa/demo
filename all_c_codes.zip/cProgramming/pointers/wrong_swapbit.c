#include<stdio.h>
unsigned int swapbit(unsigned int );
int main()
{
	unsigned int var;
	scanf("%x",&var);

        printf("%x",swapbit(var));


}
unsigned int swapbit(unsigned int var)
{

	int i,j;
	printf("swap bit no."); scanf("%d %d",&i,&j);

	char *p;
	char temp;

	p=&var;
	temp= *(p+i);
	*(p+i)=*(p+j);
	*(p+j)=temp;

	return var;




}
