#include<stdio.h>
int main()
{

	char ch1='a',ch2;
	void *p;
	p=&ch1;

	ch2=*(char *)p;

	printf("%c",ch2);
}
