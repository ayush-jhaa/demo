#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc == 1) {
        printf("error");
        exit(1);
    }

    while (--argc) {
        printf("%s", *++argv);

        while (**argv) {
            printf("%c", *(*argv)++);
        }

        putchar('\n');
    }

    return 0;
}

