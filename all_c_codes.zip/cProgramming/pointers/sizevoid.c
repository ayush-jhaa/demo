#include<stdio.h>
int main()
{

	char *p;
	void *ptr;
	int *q;

	printf("%d",sizeof(ptr));
}
