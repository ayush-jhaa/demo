#include<stdio.h>
int main()
{

	char *p;
	int *q;
	double *r;

	p=q=r=NULL;

	printf("%u %u %u",p,q,r);
	p++; q++; r++;

	printf("\n");

	printf("%u %u %u",p,q,r);

}
