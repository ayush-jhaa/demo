#include<stdio.h>
int main()
{

	int i=100,j=200;
	const int *x=&i;
	x=&j;
	printf("%d",*x);
}
