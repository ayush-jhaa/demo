#include<stdio.h>
int main()
{

	int i=260;
	char *ptr=&i;
	*++ptr=3;
	printf("%d",i);
}
