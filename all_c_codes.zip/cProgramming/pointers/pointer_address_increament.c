#include<stdio.h>
int main()
{

	float f=23.4;
	char *p=&f;
	char ch;

	ch=*p++;
	printf("%d",ch);

	ch=*p++;
        printf("%d",ch);

	ch=*p++;
        printf("%d",ch);

	ch=*p++;
        printf("%d",ch);

	
}
