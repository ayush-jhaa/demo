#include<stdio.h>
int main()
{

	char ch1='A',ch2;
	void *p;
	p=&ch1;

//	ch2= *p;  //generic pointer must be typrcast before assigning value of other datatype. wrong way

	ch2=*(char *)p; // correct way

//	ch2=(char *)*p;   //wrong method for derefrencing of void pointer.

	printf("%d",ch2);
}
