#include<stdio.h>
void swap(int *min, int *max)
{
        int temp;

        int a= *min;
        int b= *max;

        temp=a;
        a=b;
        b=temp;
}
int prime(int );
int main()
{

	int min,max;
	scanf("%d %d",&min,&max);

	if(min>max)
	{
	
		swap(&min,&max);

		for(min;min<=max;max++)
		{
		
			prime(min);
			printf("%d ",prime(min));
		}
	}
}


int prime(int min)
{

	int i;

	for(int i=2;i<min;i++)
	{
	
		if(min%i==0)
		{
		
			break;
		}
	}
	if(i==min)
	{
	
		return min;
	}

}



