#include<stdio.h>
void printBin(char ch);
int main()
{

	float f=23.4;

	char *ptr=&f;

	int i;

	for(i=3;i>=0;i--,printf(" "))
	{
	
		printBin(*(ptr+i));
	}
}

void printBin(char ch)
{

	int bit;
	for(bit=7;bit>=0;bit--)
	printf("%d",(ch>>bit)&1);
}
