#include<stdio.h>
int main()
{

	int i=258,*ip;
	char *cp;

	ip=&i;
	cp=&i;

	printf("*ip=%d *cp=%d \n",*ip,*cp);

	*++cp;
	*cp='a';

	printf("*ip=%d *cp=%d",*ip,*cp);
}
