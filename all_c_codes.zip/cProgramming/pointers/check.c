#include<stdio.h> 
const int x=10;
int main()
{

//  const int static x=10;
	int *ptr;
	const int *x
	x=ptr=&x;
	++*ptr;

	printf("%d",x);
}
