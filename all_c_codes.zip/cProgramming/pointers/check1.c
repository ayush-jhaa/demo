#include<stdio.h>
//const int i=10;
int main()
{

	const int i=10;
//         int  * const p;
        const int *p;
	int *q;
	p=q=&i;
	*q=20;

	printf("i=%d *p=%d *q=%d",i,*p,*q);

}
