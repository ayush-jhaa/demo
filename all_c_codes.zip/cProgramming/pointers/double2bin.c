#include<stdio.h>
int main()
{

	double d=23.4;

	long long int x;

	long long int *p=&d;

	x=*p;

	int bit=63;

	for(;bit>=0;bit--)
	{
	
		printf("%d",(x>>bit)&1);
	}

}
