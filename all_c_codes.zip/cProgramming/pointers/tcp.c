#include<stdio.h>

int testlittlendian(void)
{

	int v=1;
	char *p=&v;

	return (*p);
}

unsigned  short int htons( unsigned short int var )
{

	char *p;
	char temp;
	if(testlittlendian())
	{
/*	
		p=&var;
		temp=*p;
		*p=*(p+1);
		*(p+1)=temp;
*/
		var=var<<8|var>>8;
	}

	return var;
}
int main()
{

//	unsigned short int temp=0;
	unsigned short int var;
	scanf("%hd",&var);
	unsigned short int conv=htons(var);
	printf("%d",conv);
}
