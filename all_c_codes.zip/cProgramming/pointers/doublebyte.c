#include<stdio.h>
int main()
{

	double d=23.4;

	char *p=&d;

	int i,j;

	for(i=7;i>=0;i--,printf(" "))
	{
		for(j=7;j>=0;j--)
		{
		
			printf("%d",(*(p+i)>>j)&1);
		}
	}

}
