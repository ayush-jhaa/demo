#include<stdio.h>
int main()
{

	float f=23.4;

	int x;

	int *p=&f;

	x=*p;

	int bit=31;

	for(bit;bit>=0;bit--)
	{
	
		printf("%d ",(x>>bit)&1);
	}
}
