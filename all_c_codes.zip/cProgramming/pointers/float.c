#include<stdio.h>
int main()
{

	float f=23.4;

	char *p=(char *)&f;

	char ch;

	ch=*(p+3);

	printf("%d ",ch);
	ch=*(p+2);
	printf("%d ",ch);
	ch=*(p+1);
	printf("%d ",ch);
	ch=*p;
	printf("%d ",ch);


}
