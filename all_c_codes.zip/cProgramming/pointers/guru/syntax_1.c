#include<stdio.h>
int main()
{

	int i=10,j=20,k;
	int *p;
	p=&i;

	*p=i;
	printf(" *p=%d i=%d",*p,i);

}
