#include<stdio.h>
int main()
{

	short int s1,s2;
	scanf("%d %d",&s1,&s2);
	printf("%d %d",s1,s2);
}
