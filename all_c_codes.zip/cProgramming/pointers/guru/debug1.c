#include<stdio.h>
int main()
{

	int i=10,j=20;
	int *p;

	p=&i;
	*p=100;
	p=&j;

	printf("%d",*p);
}
