#include<stdio.h>
const int i=24;

int main()
{
       
	int i=24;
//	const int *p;
//	int *q;

//	p=q=&i;
//      p=&i;
//	*p=10;
//	*q=10;
        
        int *const p=&i;

	*p=20;

	

	printf("%d %d",*p,i);
}
