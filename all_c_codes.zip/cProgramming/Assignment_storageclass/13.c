#include<stdio.h>
 int i;
void inc(void)
 {
 i++;
 }
 int main()
 {
 inc();
 inc();
 printf("%d", i);
 }

