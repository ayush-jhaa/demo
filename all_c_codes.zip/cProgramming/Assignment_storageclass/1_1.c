void inc(void)
 {
	 extern int i;
// int i=12;
 ++i;
 }
