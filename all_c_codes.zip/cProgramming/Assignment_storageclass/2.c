#include<stdio.h> 
static int i=10;
int main()
 {
 inc();
 inc();
 printf("%d", i);
 }

void inc(void)
 {
	 extern int i;
// int i=12;
 ++i;
 }

