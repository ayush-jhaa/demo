void inc(void)
{
  extern int x;// also try without extern.
 ++x;
}
