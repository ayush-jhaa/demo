int x = 10;
void inc(void);
int main()
{
 inc();
 inc();
 inc();
 printf("%d",x);
}

