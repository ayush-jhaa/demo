#include<stdio.h> 
static int i=10;
int main()
 {
 inc();
 inc();
 printf("%d", i);
 }

