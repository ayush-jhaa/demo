void inc(void)
 {
  int i=15;
 ++i;
 }

