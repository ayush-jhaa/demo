 void inc(void)
 {
	 extern int i;

    ++i;
 }
