#include<stdio.h>

int main(){

	int data;
	printf("enter the data: ");
	scanf("%d",&data);

        int bit=31;

	int count=0;

	for( bit;bit>=0;bit--){
	
		printf("%d",(data>>bit)&1);
		if((data>>bit)&1){
		
			count++;
		}

	}
	printf("\n The num count is : %d",count);
}
