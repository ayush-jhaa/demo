#include<stdio.h>

int main(){

	unsigned char v=0;

LABEL1:	printf("%d %c ",v,v);

	int bit=7;

LABEL2:	printf("%d",(v>>bit)&1);

	bit--;

	if(bit>=0){
	
		goto LABEL2;
	}
	printf("\n");

	v++;
	if(v<=127)

		goto LABEL1;
}
