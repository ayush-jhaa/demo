#include<stdio.h>

int main(){

	int data,bits,count=0;
	scanf("\n%d",&data);
        scanf("%d",&bits);

	while(bits>=0)
	{
	
		printf("%d",(data >>bits)&1);
		if((data>>bits)&1){
		
			count++;
		}
		bits--;
	}
	printf("\n%d is the count",count);
}
