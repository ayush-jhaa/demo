#include<stdio.h>

int main(){

	int bit,data;
	printf("enter the data : ");
	scanf("%d",&data);
	printf("enter the bit :");
	scanf("%d",&bit);


TEST :	printf("%d",(data >> bit)&1);



	--bit;
	if (bit>=0)
		goto TEST;
		

	return 0;
}
