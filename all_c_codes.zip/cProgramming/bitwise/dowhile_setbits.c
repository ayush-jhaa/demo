#include<stdio.h>

int main(){

	int data,bit;
	printf("enter the data :");
	scanf("%d",&data);

	scanf("%d",&bit);
	

	do{
	
		printf("%d",(data>>bit)&1);
		bit--;
	}
	while(bit>=0);

}
