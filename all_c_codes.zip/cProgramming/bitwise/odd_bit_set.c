#include<stdio.h>

int main(){

	int data,bit=0,count=0,y;
	printf("enter the data : ");  scanf("%d",&data);

	while(count<5){
	
		if(bit%2 == 0){
		
			bit++;
		}
		else if(bit%2 ==1){
		
			data=(1<<bit)|data;
			count++;
			bit++;
		}

	}
	printf("%d",data);

}
