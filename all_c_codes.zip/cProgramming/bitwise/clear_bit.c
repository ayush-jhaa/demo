#include<stdio.h>

int main(){

	int data,bit;
        printf("enter data :");	scanf("%d",&data);
	printf("enter the bit :"); scanf("%d",&bit);

	data= data&(~(1<<bit));

	printf("output is :%d",data);




}
