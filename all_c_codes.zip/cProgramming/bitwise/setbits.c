#include<stdio.h>

int main(){

	int bit,data;
	printf("enter the data : ");
	scanf("%d",&data);
	printf("enter the bit :");
	scanf("%d",&bit);
	int count=0;


TEST :	printf("%d",(data >> bit)&1);


	if((data >> bit)&1 ==1){
	
		count++;
	}



	--bit;
	if (bit>=0)
		goto TEST;
	printf("\n%d set bit are there",count);
		

	return 0;
}
