#include<stdio.h>

int main(){

	unsigned char v=0;

	do{
	
		printf(" %d %c",v,v);
		printf("\n");

		int bit=7;

		do{
		
			printf("%d",(v>>bit)&1);
			bit--;

		}
		while(bit>=0);
		v++;
	}
	while(v<=127);


}
