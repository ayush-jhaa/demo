#include<stdio.h>

int main(){

	int v,bit;
	scanf("%d",&v);
	scanf("%d",&bit);

	do{
	
		printf("%d",(v>>bit)&1);
		bit--;
	}
	while(bit>=0);

       int count=0;
	bit=31;

	do{
	
		if((v>>bit)&1){
		
			if(v>>(bit-1)&1){
			
				count++;
	               		bit--;
			}
		}
		bit--;

	}
	while(bit>=0);

	printf("\nThe bit pairs are : %d",count);
	

}
