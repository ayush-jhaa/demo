#include<stdio.h>

int main(){

	int bit,data;
	printf("enter the data : ");
	scanf("%d",&data);
	printf("enter the bit :");
	scanf("%d",&bit);
	


LOOP1 :	printf("%d",(data >> bit)&1);


	--bit;
	if (bit>=0)
		goto LOOP1;
	


	int count=0;
	bit=31;
LOOP2 : if((data>>bit)&1){
	
		if((data>>bit-1)&1){
		
			count++;
			bit--;

		}
	}

                  bit--;
		  if(bit>0)
	goto LOOP2;	  

	 printf("\n%d",count) ;

	 return 0;
}
