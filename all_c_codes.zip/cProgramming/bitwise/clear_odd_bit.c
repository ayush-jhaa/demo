#include<stdio.h>
int main(){

	int data,bit=0,count=0;
	printf("enter the data :"); scanf("%d",&data);

	while(count<5){
	
		if(bit%2 ==1){
		
			data= data&(~(1<<bit));
			count++;
		}
		bit++;
	}
	printf("%d",data);
}
