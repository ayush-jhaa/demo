#include<stdio.h>

int main(){

	int data;
	scanf("%d",&data);

	int bit=31;
	

//	data= data& (1<<bit);
        
	for(bit;bit>=0;bit--)
	{
		printf(" %d",data&(1<<bit));

	}
}
