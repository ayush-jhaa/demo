#include<stdio.h>

int main(){

	unsigned char v=0;

	while(v<=127){

		printf("%d %c ",v,v);

		int bit=7;

		while(bit >=0){
		
			printf("%d",(v>>bit)&1);
			bit--;

		}
		printf("\n");
		v++;
	

	}
}
