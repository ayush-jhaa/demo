#include<stdio.h>
int main(){

	int data,bits;
	scanf("%d",&data);
	scanf("%d",&bits);

	while(bits>=0){
	
		printf("%d",(data>>bits)&1);

		bits--;
	}

	int count=0;
	bits=31;
	while(bits>=0){
	
		if((data>>bits)&1){
		
			if((data>>bits-1)&1){
			
				count++;
				bits--;	
			}
		}
		bits--;
	}
	printf("\n%d",count);
}
