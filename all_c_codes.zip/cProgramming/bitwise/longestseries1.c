#include<stdio.h>

int main()
{

	int data,count=0,y=-1;
	int found=0;
	scanf("%d",&data);
	
	int bit=31;
	

	if(data==0)
	{
	
		printf("no series of 1's");
		
	}
	else
	{

	for(bit;bit>=0;bit--)
	{
	
		if(((data>>bit)&1)==1)
		{
			count++;
			
			if(bit ==0)
			{
			
				if(count>y)
				{
				y=count;

				found=1;

				}
			}
			

		}
		else  if(((data>>bit)&1) == 0)
		{
		
			if(count>y)
			{
				y=count;
			        count=0;
				
				found=1;
			}
			else
			{
			    count =0;
			}
			
		}
		
	}
	if(found){
	printf("%d",y);
}  }}
