#include<stdio.h>

int main(){

	int data;
	printf("enter the data: "); scanf("%d",&data);
	int bit; scanf("%d",&bit);

	
	
		data=(1<<bit)|data;
		bit--;
	
	printf("%d",data);
}
