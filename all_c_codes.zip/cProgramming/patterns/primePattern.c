#include<stdio.h>

int prime (int a);
int main()
{
	int n,i,j;
	scanf("%d",&n);
 
        int a;
	printf("enter the prime num");
	scanf("%d",&a);

	for(i=1;i<=n;i++)
	{
	
	
		for(j=1;j<=i;j++)
		{
                  while(!prime(a))
                  {
		  
			  ++a;
		  }	
                   printf("%d ",a);
                    //  ++a;		   
		      
		 	
		}
		++a;

		printf("\n");
	}


}

int prime(int a)
{
  int i=1,count=0;

  if(a<=1)
   return 0;
  
  for(i;i<=a;i++)
  {
	  if(a%i==0)
	  {
	  
		  count++;
	  }
  

  }
  if(count==2)
  {

	  return 1;
  }
  else if(count>2)
	  return 0;

}
