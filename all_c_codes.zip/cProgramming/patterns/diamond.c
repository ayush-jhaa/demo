#include <stdio.h>

int main(){

    int n,a;
    printf("enter the number : ");
    scanf("%d",&n);
    int nst=1;
    int nsp=n/2;
    int ml=n/2+1;
    for (int i=1; i<=n; i++)
    {
	    a=0;
        for ( int j=1; j<=nsp ; j++)
        {
		printf(" ");
        }
        for (int k=1; k<= nst; k++)
        {
		 a++;
            printf("%d",a);
        }
       if (i<ml)
       {
        nsp--;
        nst+=2;
	a++;
       }
       else
       {
        nsp++;
        nst-=2;
	a--;
       }
       
       
        printf("\n");
    }
    return 0;
    
}
