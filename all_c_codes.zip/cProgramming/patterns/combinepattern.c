#include<stdio.h>
int main()
{

	int n,i,j;
	scanf("%d",&n);

	int nst=n/2+1;
	int ml=n/2+1;

	for( i=1; i<=n;i++)
	{
	
		for(j=1;j<=nst;j++)
		{
		
			printf("*");
		}
		if(i<ml)
	        nst--;
		else
		nst++;

		printf("\n");

	}
}
