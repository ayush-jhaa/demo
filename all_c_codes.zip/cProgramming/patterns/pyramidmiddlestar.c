#include<stdio.h>
int main()
{
      int data,i,j,k;
      char ch;
      scanf("%d",&data);

      for(i=1;i<=data;i++)
      { ch='A';
	      for(j=1;j<=data-i;j++)
	     {
	     printf(" ");
	     }
	 for(k=1;k<=2*i-1;k++)
           {
	      if(k%2==0)
		printf("*");

	      else
	{
	       printf("%c",ch);
	       ch++;
	}
	 
	   }
	 printf("\n");

}
}
