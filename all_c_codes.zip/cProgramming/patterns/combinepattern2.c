#include<stdio.h>
int main()
{

	int n,i,j,k;
	scanf("%d",&n);

	int nst=n/2+1;
	int nsp=1;
	int ml=n/2+1;

	for(i=1;i<=n;i++)
        {
	
		for(j=1;j<=nsp;j++)
		{
		
			printf(" ");
		}
		for(k=1;k<=nst;k++)
		{
		       printf("*");
		}

		if(i<ml)
		{
		    nsp++;
		    nst--;
		}
		else
		{
		    nsp--;
		    nst++;
		}
		printf("\n");
	}
}
