#include<stdio.h>
extern int g;
main()
{

   printf("%d",g);
}
