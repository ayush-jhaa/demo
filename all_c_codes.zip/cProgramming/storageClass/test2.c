#include<stdio.h>
extern int g=6;
int main()
{

//	extern int g;
	printf("%d",g);
}
