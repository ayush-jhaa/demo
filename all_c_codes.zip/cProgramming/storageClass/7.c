#include<stdio.h>
int x=10;
 int main()
{
 int y=x;
 int z=y;
printf("%d %d %d",x,y,z);
}
