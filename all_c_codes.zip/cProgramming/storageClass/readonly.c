#include<stdio.h>
int main()
{
	const int v=10;
	printf("%d\n",v);
	v++;  // Error because const cannot be change.
	printf("%d",v+20);// 30 because we are not changing the v we are adding another value with b.
}
