#include<stdio.h>
int main()
{
     volatile const static int  v1=50;
      const int v2=80;

      int *p=&v1;
      int *q=&v2;

      *p=*q;

      printf("%d %d",v1,v2);
}

