#include<stdio.h>
int main()
{
     static int x=20;
     x=12;
     printf("%d",x);
}
