void fnc(void)
{

	printf("hello");
}
