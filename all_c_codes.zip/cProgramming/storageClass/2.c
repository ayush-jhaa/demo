#include<stdlib.h>
int sum(int a,int b)
{

	return a+b;
	exit(0);

}
