//int x=6;
void inc(void)

{
   int x=5;
 ++x;
 printf("%d",x);
}

