#include<stdio.h>
 int x = 10;
void inc(void);
int main()
{

 inc();
 printf("\n");
 inc();
 printf("\n");
 inc();
 printf("\n");
 printf("%d",x);
}

