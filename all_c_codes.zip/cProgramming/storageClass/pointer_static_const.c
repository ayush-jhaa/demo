#include<stdio.h>
int main()
{
	// const  int static v=10;
      volatile const int static v=10;
	int *ptr=&v;

	++*ptr;

	printf("%d",v);
}
