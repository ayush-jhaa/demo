#include<stdio.h>
//        const int v=10;

int main()
{
	const int v=10;
	int *ptr=&v;

	++*ptr;

	printf("%d",v);
}
