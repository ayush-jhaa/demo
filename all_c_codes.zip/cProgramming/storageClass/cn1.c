#include<stdio.h>
int g=1;
void f1(void);
void f2(void);
int  main()
{

	static int g=5;
	f1();
	printf("\n");
	f2();
	printf("\n");
	printf("%d",g);
}
void f1(void)
{

	static int g;
	g +=10;
	printf("%d",g);
}
void f2(void)
{

	static int g;
	g +=20;
	printf("%d",g);
}
