void inc(void)
 {
 int i=5;
 ++i;
 printf("%d",i);
 }
