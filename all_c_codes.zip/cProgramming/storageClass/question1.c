#include<stdio.h>
 int sum(int,int);
 int main()
 {
 int x=10,y=20;
 printf("%d",sum(x,y));
 }
