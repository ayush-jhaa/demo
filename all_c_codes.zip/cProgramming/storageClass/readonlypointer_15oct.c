#include<stdio.h>
int main()
{
    int v1=10;
    int v2=20;

    int *const p=&v1;
    *p=30;
    printf("%d",v1);
}
