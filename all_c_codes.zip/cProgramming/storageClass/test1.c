#include<stdio.h>
void f1()
{
        extern int g;	

	++g;
}
int main()
{
	extern int g;
 
	
	f1();
	printf("%d",g);

}
int g=10;
