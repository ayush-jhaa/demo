#include<stdio.h>
int main()
{

	int a=9,b=9;
	a=a++;
	a=++a;
	b=b++;
	a=b++;
	b=b++;

	printf("%d %d",a,b);
}
