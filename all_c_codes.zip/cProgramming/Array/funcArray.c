#include<stdio.h>

void printA(char*,int);
void printB(char*,int);

int main()
{

	char a[]={'v','e','c','t','o','r'};
	char b[]={1,2,3,4,5,6};

	printA(a,sizeof(a)/sizeof(*a));
	printB(b,sizeof(b)/sizeof(*b));
}

void printA(char *a,int n)
{
      int i;
      for(i=0;i<n;i++)
      {
           printf("%c",a[i]);
	
      }
}

void printB(char *b,int n)
{
	printf("\n");
     
	int i;
	for(i=0;i<n;i++)
        {
	    printf("%d",b[i]);
	}
}
