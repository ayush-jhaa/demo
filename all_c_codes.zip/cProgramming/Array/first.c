#include<stdio.h>
int main()
{

	int arr[3]={11,22,33,44,55,66};

	printf("%d",arr[2]);
}
