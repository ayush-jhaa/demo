#include<stdio.h>
int main()
{

	char a[]={'v','e','c','t','o','r'};
	printf("%ld",sizeof(a)/sizeof(a[0]));

}
