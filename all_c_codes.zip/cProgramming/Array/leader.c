#include<stdio.h>
#include<string.h>

void leader(int *,int);
int main()
{
     int size,i;
     puts("enter the size: ");
     scanf("%d",&size);
     int arr[size];

     for(i=0;i<size;i++)
      {
           scanf("%d",&arr[i]);
      }

     leader(arr,size);

}

void leader(int a[],int n)
{
     int i,j,flag;

     for(i=0;i<n;i++)
      {
	 flag=0;
         for(j=i+1;j<n;j++)
          {
	        if(a[i]<a[j])
	        {
		 flag=1;
	         break;
	        }
		
	  
          }
              if(flag==0)
                {
                   printf("%d ",a[i]);
                }
      }
}
