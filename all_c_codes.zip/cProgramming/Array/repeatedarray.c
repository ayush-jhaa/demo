#include <stdio.h>

void printnum(int arr[], int n);

int main() {
    int arr[20], i, n;
    scanf("%d", &n);
    if (n <= 0) {
        printf("invalid size");
        return 0;
    }
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    printnum(arr, n);
    return 0;
}

void printnum(int arr[], int n) {
    int i, j, cnt = 0,cnt=0;
    for (i = 0; i < n; i++) {
        for (j = 0`; j < n; j++) {
            if (arr[i] == arr[j]) {
		    ++cnt;

		    if(cnt==1)
	      {
                printf("%d ", arr[j]);
                
		break;
	      }
            }
        }
    }
    if (cnt == 0)
        printf("no repeated elements");
}

