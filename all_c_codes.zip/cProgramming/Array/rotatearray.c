#include <stdio.h>

int main() {
    int SIZE;
    scanf("%d", &SIZE);

    // Write a condition to test if SIZE/number of elements are in range or not
    if (SIZE <= 0 || SIZE > 100) {
        printf("Number of elements is invalid\n");
        return 0;
    }

    int a[100], i;

    for (i = 0; i < SIZE; i++) {
        
        scanf("%d", &a[i]);
    }

    char choice;
    // Enter choice for array rotation as 'r' for right, 'l' for left
    scanf(" %c", &choice);

    int nOR;
    // Enter how many positions to rotate
    scanf("%d", &nOR);

    while (nOR > 0) {
        int temp;
        if (choice == 'r') {
            // Write logic to rotate right, can perform with the help of a temp variable
	    int temp=a[SIZE-1];
	    for(i=SIZE-1;i>0;i--)
	       {
	           a[i]=a[i-1];
	       }
	    a[0]=temp;
        }
       	else if (choice == 'l') {
            // Write logic to rotate left, can perform with the help of a temp variable
	    int temp=a[0];
	    for(i=0;i<SIZE-1;i++)
	     {
	        a[i]=a[i+1];
	     }
	    a[SIZE-1]=temp;
        }
        nOR--;
    }

    // printf("Array Elements are:\n");
    for (i = 0; i < SIZE; i++) {
        // Print array elements
         printf("%d ", a[i]);
    }

    return 0;
}

