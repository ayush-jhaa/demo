#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int findmax(int *,int);
void print(int *a,int n)
{

	int i;
	printf("the list :");

	for(i=0;i<20;i++)
	{
	
		printf("%d ",a[i]);
	}
	printf("\n");
}

void input(int *p,int n)
{

	int i;
	srand(getpid());

	for(i=0;i<n;i++)
	{

	p[i]=rand()%20;

	}
}

int main()
{

	int arr[20],max,i;

	//input from user.
	input(arr,20);

	//print  the numbers.
	print(arr,20);

	//find the max value.
	printf("the max value is %d",findmax(arr,20));
}

int findmax(int *a,int n)
{

	int i=0,max;
	for(max=a[0],i=0;i<20;i++)
	{
	
		if(a[i]>max)
		{
		
			max=a[i];
		}
	}
	return max;

}
