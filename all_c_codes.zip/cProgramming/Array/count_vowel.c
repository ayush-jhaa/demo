#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

void input(char *a,int n)
{
       int i;
       srand(getpid());
       for(i=0;i<n;i++)
       {
          a[i]=rand()%26+97;
       }


}

void print(char *a,int n)
{
     int i=0;
     for(i=0;i<n;i++)
     {
         printf("%c ",a[i]);
     }
}

int cntvowel(char *v,int n)
{
   
         int cnt=0;

	 while(n--)
         {
	 
		 switch(*v++)
			{
			 case 'a':
		         case 'e':
		         case 'i':
			case 'o':
			case 'u':cnt++;
			
			
			}
	 }
	 return cnt;
     }

int main()
{

	char arr[20];

	//taking input from array.
	input(arr, sizeof(arr)/sizeof(*arr));

	//print the array.
	print(arr,sizeof(arr)/sizeof(*arr));

	//cnt vowel
	printf("%d",cntvowel(arr,sizeof(arr)/sizeof(*arr)));
	
}
