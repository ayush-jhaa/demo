#include <stdio.h>

void max_sum(int *, int, int);

int main() {
    int arr[20];
    int n, i, temp = -1;
    scanf("%d", &n);
    if (n <= 0) {
        printf("invalid main array size");
        return 0;
    }
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    int subarray;
    scanf("%d", &subarray);
    max_sum(arr, n, subarray);
}

void max_sum(int arr[], int max, int length) {
    int i, j, temp = -1, store, l;
    for (i = 0; i < max; i++) {
        store = 0;
        l = length + i; // l check karega user defined length from any number to max number.
        if (l > max)
            break; // sirf utne length tak check karna hai na kam na jyada.
        for (j = 0 + i; j < l; j++) {
            store = store + arr[j];
        }
        if (store > temp) {
            temp = store;
        }
    }
    printf("%d", temp);
}

