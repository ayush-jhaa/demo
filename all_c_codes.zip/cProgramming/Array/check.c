#include<stdio.h>
int main()
{
    int arr[10];
    int *ptr;

    scanf("%d",arr+1);
    printf("%d",arr[1]);
   
   // printf("%p",&arr);
}
