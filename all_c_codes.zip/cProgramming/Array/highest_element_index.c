#include<stdio.h>
void highestindex(int arr[],int);
int main()
{
     int size,i;
     puts("enter the size");
     scanf("%d",&size);
     int arr[size];

     for(i=0;i<size;i++)
      {
          puts("enter the elements :");
	  scanf("%d",&arr[i]);
      }

     highestindex(arr,size);


}

void highestindex(int a[],int max)
{
       int temp,val,i;
       val=a[0];

       for(i=0;i<max;i++)
        {
	   if(a[i]>val)
	   {
	       temp=i;
	       val=a[i];
	   }
	}
       printf("%d",temp);
}
