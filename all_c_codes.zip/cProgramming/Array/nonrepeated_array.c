#include<stdio.h>
#include<string.h>
void nonrepeated(int a[],int size);

int main()
{
    int arr[50],i;
    int size;

label1:
    puts("enter size :");
    scanf("%d",&size);
    if (size<=0)
    {
       puts("invalid size");
       goto label1;

    }

    for(i=0;i<size;i++)
       {
         scanf("%d",&arr[i]);
       }
    
    nonrepeated(arr,size);

}

void nonrepeated(int a[],int size)
{
    int i,j,flag;

    for(i=0;i<size;i++)
      {
	      flag=0;
         for(j=0;j<size;j++)
           {
	        if(i!=j && a[i]==a[j])
	        {
		 //  a[j]=-1;
		   flag=1;
		   
		   break;
		}
	   }
	 if(flag==0)
	 printf("%d ",a[i]);
	
      }
    if(flag==1)
	    printf("no non repeated element");
    


}
