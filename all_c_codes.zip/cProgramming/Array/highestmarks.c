#include<stdio.h>
int main()
{

	//Take input from the user
	int arr[20],max,i;
	
	for(i=0;i<20;i++)
	{

		printf("enter marks of student number %d: ",i+1);
	      scanf("%d",&arr[i]);
        //       arr[i]=max;
	}

        //print the marks
	printf("The list of marks students got are \n");

	for(i=0;i<20;i++)
        {
	
		printf("%d ",arr[i]);
	}


	//highest marks
	
	int high=arr[0];

	for(i=1;i<20;i++)
	{
	
		if(arr[i]>high)
		{
		     high=arr[i];
		}
	}
	printf("\nhighest marks: %d ",high);
}
