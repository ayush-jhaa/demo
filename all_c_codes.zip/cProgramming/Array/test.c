#include<stdio.h>
int main()
{
     int arr[]={22,33,13,16};
     printf("%d",arr[0]);
}
