#include<stdio.h>
#include<string.h>

void zerosend(int* ,int);
int main()
{
   int size,i;
   puts("enter the size");
   scanf("%d",&size);

   if(size<=0)
   {
       puts("invalid size");
       return 0;
   }
  
   int arr[size];
   puts("enter the elements in array:");
 
   for(i=0;i<size;i++)
   {
       scanf("%d",&arr[i]);
   }

   zerosend(arr,size);

   return 0;
}

void zerosend(int arr[],int size)
{
     int i,j=0;

     for(i=0;i<size;i++)
      {
	      if(arr[i] !=0)
	      {
	         arr[j]=arr[i];     //manipulating the array.
		 j++;
	      }
 }

     while(j<size)
	{
	   arr[j]=0;
	   j++;
	}
     

     for(i=0;i<size;i++)
      {
          printf("%d ",arr[i]);
	  
      }
}
