#include<stdio.h>
int main()
{
   int rollno[5];
   int name[5][10];
   float marks[5]; 

   ele= sizeof(rollno)/sizeof(rollno[0]);

   for(int i=0;i<ele;i++)
   {
        printf("enter the roll no.\n");
	scanf("%d",&rollno[i]);

	printf("enter the name");
	scanf("%s",name[i]);

	printf("enter the marks");
	scanf("%f",&marks[i]);
   }  

  for(int i=0;i<ele;i++)
  {
      printf("%d %s %.2f",rollno[i],name[i],marks[i]);  
  } 
}
