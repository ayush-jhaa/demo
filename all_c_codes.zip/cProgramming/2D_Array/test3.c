#include<stdio.h>
int main()
{
    char s[][10]={"ABCD","EFGH","IJKL"};
    PRINT(s,3);
}

void PRINT(char **p,int n)
{
    
    int i=0;
    for(i=0;i<n;i++)
    {
        printf("%s\n",p[i]);  // pointing to single char giving segm fault because string need to access next letter inprooperly.
    }
}
