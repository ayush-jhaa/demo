#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main()
{
     int arr[10][10];
     int i,j;

     int rows=sizeof(arr)/sizeof(*arr);
     int cols=sizeof(*arr)/sizeof(**arr);

        srand(getpid());

     for(i=0;i<rows;i++)
      {
	   
          for(j=0;j<cols;j++)
          {
	     arr[i][j]=rand()%101;
	  }
      }

     int highest=0;
     int num;
     int index;
     for(i=0;i<rows;i++,printf("\n"))
     {
	    printf("student no. %d:",i);

	     num=0;
          for(j=0;j<cols;j++)
           {
	      num=num+arr[i][j];
	       printf("%4d",arr[i][j]);
	   }

	  if(num>highest)
           {
	      highest=num;
	      index=i;
	   }
     }
     printf("%d %d",highest,index);
}
