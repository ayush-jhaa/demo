// Write a program to store 10 student marks of six subjects.Find total marks of each student. And provide following result.

// A. Who got highest marks finally.
// B. Who got highest marks in each subject.

// Hint:  Take 2D array with 10 rows and 6 columns. 


#include<stdio.h>
#include<stdlib.h>

void Input(int (*)[],int,int);
void Print(int (*)[],int,int);
void totalmarks(int (*)[],int,int);
int highestmark(int(*)[],int,int);
void subject(int(*)[],int,int);

int main()
{
   int marks[10][7];
   int r,c;

    r=sizeof(marks)/sizeof(*marks);
    c=sizeof(*marks)/sizeof(**marks);

    // input
   Input(marks,r,c);

    // total marks
   totalmarks(marks,r,c);
   Print(marks,r,c);
   printf("---------------------------------------------------------\n");
   
    //  highest marks by student
   int index=highestmark(marks,r,c);
   printf(" student %d got highest marks :%d",index+1,marks[index][6]);
   printf("\n");
   
    // highest marks subject wise
   subject(marks,r,c);   





}

void Input(int (*p)[7],int r,int c)
{
     int i,j;
     srand(getpid());
     for(i=0;i<r;i++)
     {
       for(j=0;j<c-1;j++)
       {
          p[i][j]=rand()%101;
       }
     }
}

void Print(int (*p)[7],int r,int c)
{
       int i,j;
       for(i=0;i<r;i++,printf("\n"))
       {
          printf("student %2d:",i+1);	 
          for(j=0;j<c;j++)
          {
             if(j==(c-1))
	     printf("=%4d",p[i][j]);

	     else
	    printf("%4d",p[i][j]);
	  }

       }
}

void totalmarks(int (*p)[7],int r,int c)
{
        int i,j;
	int sum;
	for(i=0;i<r;i++)
        {
	   sum=0;
	 for(j=0;j<c-1;j++)
          {
	      sum +=p[i][j];
	  }

	  p[i][j]=sum;
	 
	}
}

int highestmark(int (*p)[7],int r,int c)
{
     int highest=0;
     int i,index=0;

     for(i=0;i<r;i++)
       {
          if(p[i][6]> highest)
	   {
	      highest=p[i][6];
	      index=i;
	   }
       }
       return index;
}

void subject(int (*p)[7],int r,int c)
{
     int highest=0;
     int j,i,index=0;

     for(j=0;j<c-1;j++)
     {
	     highest=0;
        for(i=0;i<r;i++)
        {
	   if(p[i][j]>highest)
            {
	        highest=p[i][j];
		index=i;
	    }
	}
	printf("student %d got highest marks in sub %d\n",index+1,j+1);
     }
     
}
