//Write a program to transpose a matrix
#include<stdio.h>

void  transposematrix(int rows,int cols,int matrix[10][10])
{
    int i,j,temp[10][10];
    for(j=0;j<cols;j++)
    {
       for(i=0;i<rows;i++)
	 {
	    temp[j][i]= matrix[i][j];
	 }
    }

    
    for(j=0;j<cols;j++)
    {
       for(i=0;i<rows;i++)
	 {
	    matrix[j][i]= temp[j][i];
	 }
    }
}

void inputmatrix(int rows,int cols,int matrix[10][10])
{
     int i,j;
     for(i=0;i<rows;i++)
      for(j=0;j<cols;j++)
            scanf("%d",&matrix[i][j]);
       
}

void printmatrix(int rows,int cols,int matrix[10][10])
{
      
     int i,j;
     for(i=0;i<rows;i++)
     {
      for(j=0;j<cols;j++)
      {
	      printf("%d ",matrix[i][j]);
      }
      printf("\n");
     }
}
int main()
{
    int rows,cols;
    int matrix[10][10];

    printf("enter  rows:"); scanf("%d",&rows);       
    printf("enter  cols:"); scanf("%d",&cols);

    // input matrix
    inputmatrix(rows,cols,matrix);

    // print matrix
    printmatrix(rows,cols,matrix);

    // transpose logic
    transposematrix(rows,cols,matrix);

    // transpose matrix
     printf("transpose matrix:\n");
     printmatrix(cols,rows,matrix);
}
