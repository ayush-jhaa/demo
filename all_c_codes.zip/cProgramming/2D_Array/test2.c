#include<stdio.h>
int main()
{
    int arr[3][4]={{11,22,33},{44,55,66},{77,88,99}};
    int (*p)[3];
    int (*q)[4];
    int (*r)[5];
    int **s;
    p=q=r=s=arr;
    printf("%u %u %u %u %u",arr[1][1],p[1][1],q[1][1],r[1][1],s[1][1]);
}
