#include<stdio.h>

int main(){


	int n=56,r;

	r=n/0;

	printf("%d",r);

	
}
