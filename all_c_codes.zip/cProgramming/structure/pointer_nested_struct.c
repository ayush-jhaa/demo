#include<stdio.h>
#include<stdlib.h>

struct subject
{
     float s1;
     float s2;
     float s3;
}; 

struct stu 
{
   int roll;
   char* name;
   float marks;
   struct subject *sub;
};


int main()
{
  // struct stu v;
  // scanf("%f",&v.sub.s1);

  // printf("%.2f",v.sub.s1);
  
  struct stu v;
  v.sub= calloc(1,sizeof(struct subject));
  scanf("%f",&v.sub->s1);
  printf("%f",v.sub->s1);
}
