#include<stdio.h>
#include<string.h>

struct stu 
{
   int roll;
   char name[20];
   float marks;
};

int main()
{
      struct stu v;
      v.roll=40;
      strcpy(v.name,"ayush");
      v.marks=94;

      printf("%d %s %.2f",v.roll,v.name,v.marks);
}
