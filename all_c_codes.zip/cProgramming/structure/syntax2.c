#include<stdio.h>

struct stu
{
    int x;
    char ch;
    float f;
}*v=&(struct stu){12,'A',12.34};

int main()
{
   printf("%d",v->x);
}
