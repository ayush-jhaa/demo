#include<stdio.h>
#include<stdlib.h>

struct str
{
     char name[20];
     int rollno;
     float marks;

};

int main()
{
   struct str stu1={"harry",39,78};
   struct str stu2;
   scanf("%s",stu2.name);
   scanf("%d",&stu2.rollno);
   scanf("%f",&stu2.marks);

   printf("stu1: %s  %d  %.2f\n",stu1.name,stu1.rollno,stu1.marks);
   printf("stu2: %s  %d  %.2f",stu2.name,stu2.rollno,stu2.marks);

}
