#include <stdio.h>
#include <stdlib.h>

struct str
{
    char name[20];
    int rollno;
    float marks;
};

int main()
{
    struct str *arr = NULL;
    int i = 0;
    int n;
    printf("enter number of students: ");
    scanf("%d",&n);

    arr = (struct str *)malloc(n * sizeof(struct str));

    for (i = 0; i < n; i++)
    {
        printf("Enter the details for student %d:\n", i + 1);
        printf("Name: ");
	__fpurge(stdin);
        fgets(arr[i].name,15,stdin);
        printf("Roll No: ");
        scanf(" %d", &arr[i].rollno);
        printf("Marks: ");
        scanf(" %f", &arr[i].marks);
    }

    printf("Student details:\n");
    for (i = 0; i < n; i++)
    {
        printf("Student %d: %s  %3d  %3.2f \n", i + 1,arr[i].name,arr[i].rollno,arr[i].marks);
      
    }

    free(arr); // Don't forget to free the allocated memory when you're done.

    return 0;
}

