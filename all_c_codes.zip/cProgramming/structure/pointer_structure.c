#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
typedef struct student
{
     int id;
     char *name;
     float marks;
} stu;


char *getstring(void)
{
    char *p=NULL;

    int i=0;

    do
    {
	    p=realloc(p,(i+1)*sizeof(char));
	    p[i]=getchar();
    }
    while(p[i++]!='\n');

    p[i-1]='\0';

    return p;
}
int main()
{
   int size,i;
   printf("enter the size") ;
   scanf("%d",&size);  

   stu *v; 
    v= (stu *) malloc(size* sizeof(stu));

    for(i=0;i<size;i++)
 {
    printf("enter your id: ");
    scanf("%d",&v[i].id);
    __fpurge(stdin);

    printf("enter your name: ");
    v[i].name=getstring();

    printf("enter your marks: ");
    scanf("%f",&v[i].marks);
 }

    for(i=0;i<size;i++)
   {
    printf("%d %s %.2f",v[i].id,v[i].name,v[i].marks);
    printf("\n");
   }
}
