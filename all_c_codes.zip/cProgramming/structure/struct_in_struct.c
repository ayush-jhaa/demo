#include<stdio.h>

struct stu
{
  float roll;
  char *name;
  struct 
  {
      float s1;
      float s2; 
      float s3;
  }sub; 
};

int main()
{
   	
    struct stu v;
    scanf("%f",&v.sub.s1);
    printf("%f",v.sub.s1);
}
