#include<stdio.h>

struct stu
{
   int roll;
   char *name;
   float marks;
};

void *getstring(void)
{
   char *p=NULL;
   int i=0;
   do
   {
     p=realloc(p,(i+1)*sizeof(char));
     p[i]=getchar();

   }while(p[i++] !=10);

   p[i-1]='\0';

   return p;
}

int main()
{
    struct stu v;

    scanf("%d",&v.roll);
    __fpurge(stdin);
    v.name=getstring();
    scanf("%f",&v.marks);

    printf("%d %s %.2f",v.roll,v.name,v.marks);
}
