#include<stdio.h>
#include<stdlib.h>

struct subject
{
     float s1;
     float s2;
     float s3;
}; 

struct  
{
   int roll;
   char* name;
   float marks;
   struct subject sub;
}v;


int main()
{
  // struct stu v;
  // scanf("%f",&v.sub.s1);

  // printf("%.2f",v.sub.s1);
  //
  scanf("%d",&v.roll);
  printf("%d",v.roll);
}
