#include<stdio.h>

void find(char*,char*,char*);

int main()
{
  char str[30]="This is string";
  char s1[]="is";
  char s2[]="AB";

  find(str,s1,s2);
}

void find(char *arr,char*s1,char*s2)
{
     char *p=arr;
     int i;

     while(p=strstr(p,s1))
     {
	    i=0;
         while(s1[i])   // if i doesnt reset to zero then it will fetch s[3] which is null that's why never enter in the loop again and not                                                             change the value.
         {
           p[i]=s2[i];
	   i++;
	  
	 }
     p=p+2;
	
     }

     printf("%s",arr);
}
