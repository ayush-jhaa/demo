#include<stdio.h>
#include<string.h>
int main()
{
       char s1[12];
       char s2[12];
       int i;
       puts("enter the index where you want to put");
       scanf("%d",&i);

       puts("enter two string data:");
       scanf("%s %s",s1,s2);

       strcat(s2,s1+i);
       strcpy(s1+i,s2);

       printf("%s",s1);

}
