#include<stdio.h>
#include<string.h>
int main()
{
     char str[10]="abcdef";
     char *p=str;
      p=str+strlen(str)/2;
     

     memmove(p,p+1,strlen(p+1)+1);

     printf("%s",str);
}
