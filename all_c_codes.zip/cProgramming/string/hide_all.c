#include<stdio.h>
#include<string.h>
int main()
{
     char s1[30]="Today is friday";
     char s2[5]="day";

     char *p=s1;
     int l2=strlen(s2);

     while(p=strstr(p,s2))
     {
          memset(p,'*',l2);
	  p +=l2;
     }

     printf("%s",s1);

}
