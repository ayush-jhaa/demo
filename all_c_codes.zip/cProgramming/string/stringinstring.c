#include<stdio.h>
#include<string.h>

int main()
{
   char str[60];
   char s1[20];
   char s2[20];
   char s3[20];

   puts("enter first string");
   scanf("%[^\n]s",s1);
   puts("enter second string");

   scanf("%s",s2);
   puts("enter third string");

   scanf("%s",s3);

   int i,j;

   for(i=0;i<s1[i];i++)
    {
        str[i]=s1[i];
    }
   str[i++]=32;

   for(j=0;s2[j];i++,j++)
   {
        str[i]=s2[j];
   }
   str[i++]=32;

   for(j=0;s3[j];i++,j++)
   {
     str[i]=s3[j];
   }
   str[i]='\0';  

   printf("%s",str);

}
