#include<stdio.h>
#include<string.h>
void reverse(char *,char *);
int main()
{
    char arr[]="this is vector"; 
    char s1[]="is"; 
    reverse(arr,s1);
    
}
void reverse(char *arr,char *s1)
{ 
    char*p=arr;
    int i=0,l=strlen(s1);
    while(p=strstr(p,s1))
    {
        i=0;
        while(l>0)
        { 
            p[i]=s1[l-1]; 
            i++; 
            l--;
        }
	l=strlen(s1);
        p=p+l;
    }
    
    printf("%s",arr);
 //  printf("%d",l); 
   
} 
