#include<stdio.h>
#include<string.h>

int main()
{
     char str[20];
     char *p=str;
     int i=0;


   // write the input data.
     gets(str);
     printf("original string= %s\n",str);

     //calculate the position
     while(str[i])
     {
         if(str[i]=='a' || str[i]=='e' || str[i]=='i'|| str[i]=='o'||str[i]=='u')
	  {
	     p=str+i;
	     memmove(p,p+1,strlen(p+1)+1);
	  }
	 
	 else
	 ++i;
	 
     }
     puts("string without vowels are:");
     puts(str);
}
