#include<stdio.h>
#include<string.h>

int main()
{
       char s1[]="ABCDABCABCDE";
       char s2[]="BCD";

       char *p;
       p=s1;
       int l2=strlen(s2);

       while(p=strstr(s1,s2))
       {
         memmove(p,p+l2,strlen(p+l2)+1);
       }

       printf("%s",s1);
}
