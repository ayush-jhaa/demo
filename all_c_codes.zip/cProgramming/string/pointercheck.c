#include<stdio.h>

void convert(char s1[])
{
   s1=s1+2;

   printf("%c",s1[-3]);
}

int main()
{
   char  s1[]="This";
//    char *p=s1;
//    p=p+2;
       
//    *p='a';
//       s1=s1+2;

     convert(s1);  
//    printf("%s\n",s1);

/*    char *q;
   q=p;
    ++q;
    *q='a';

//    printf("%s %s\n",p,q); */
//    printf("%s",s1); 
//      printf("%s",(s1+2));


}
