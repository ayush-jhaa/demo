#include<stdio.h>
#include<string.h>
int main()
{
      char s1[30];
      char s2[30];

      puts("enter the first string");
      scanf("%s",s1);

      puts("enter the second string");
      scanf("%s",s2);

      int pos;
      printf("enter position number ");
      scanf("%d",&pos);
      
      int l2=strlen(s2);
      int i;

      for(int i=strlen(s1);i>=pos;i--)
	 {
	      s1[i+l2]=s1[i];
	 }
      strncpy(s1+pos,s2,l2);

      printf("%s",s1);

}
