#include<stdio.h>
#include<string.h>

int main()
{
      char str[20];

      scanf("%s",str);

//      strcpy(str,"vector"); // allowed 
        strcpy("vector",str);
      printf("%s",str);


}
