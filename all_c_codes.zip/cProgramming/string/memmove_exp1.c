#include<stdio.h>
#include<string.h>
int main()
{
     char str[20]="hellodear";
     
     memmove(str+2,str,9);

     printf("%s",str);
}
