#include<stdio.h>
#include<string.h>

int isvalid(char *);
int stoi(char *);
long long int bintodec(long long int);

int main()
{
  long long int n;
   char str[20];

LABEL:
       
   puts("enter decimal value");
   scanf("%s",str);
   
   // checking validity condition
   if(!isvalid(str))
    {
        puts("invalid input");
	goto LABEL;
    }

   //converting string to int
    n=stoi(str);

  //binary to decimal
    printf("%lld",bintodec(n));

}

int isvalid(char *v)
{ 

   for(;*v;v++)
 {
     if(*v<48 || *v>49)
	return 0;
 }
   return 1;

}

int stoi(char *v)
{
   int n=0;

   for(;*v;v++)
   {
       n=n*10+*v-48;    
   }

   return n;
}

long long int bintodec(long long int n)
{
	long long int rem,sum=0,pow=1;

	while(n>0)
	{
	   rem=n%10;
	   rem=rem*pow;
	   pow=pow*2;
	   sum=sum+rem;
	   n /=10;
	}
	return sum;
}
