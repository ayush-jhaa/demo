#include<stdio.h>
#include<string.h>
int main()
{
      char s1[20]="This is Vector";
      char s2[10]="is";
      char s3[10]="AB";

      char *p=s1;
      int l3=strlen(s3);

      while(p=strstr(p,s2))
      {
           memset(p,s3,l3);
	   memmove(p,p+l3,strlen(p+l3)+1);
      }

      printf("%s",s1);
}
