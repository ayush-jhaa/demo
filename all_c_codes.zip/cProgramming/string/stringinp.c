#include<stdio.h>
#include<string.h>
int main()
{

	char  str[20];
	puts("enter a string");
//	scanf("%[^.]s",str);
       fgets(str,20,stdin);
//      gets(str);
	printf("str:%s\n",str);
	printf("%lu %lu\n",sizeof(str),strlen(str));
}
