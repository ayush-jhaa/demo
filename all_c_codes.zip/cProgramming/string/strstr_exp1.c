#include<stdio.h>
#include<string.h>
int main()
{
     char s1[30]="Today is Thursday";
     char s2[10]="day";

     char *p=s1;
     int cnt=0;
     int l2=strlen(s2);

     while(p=strstr(p,s2))
     {
            cnt++;
	    p +=l2;
	    
     }

    printf("%d",cnt);
}
