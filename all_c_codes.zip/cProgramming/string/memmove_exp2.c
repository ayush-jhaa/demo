#include<stdio.h>
#include<string.h>
int main()
{
      char s1[30]="ABCDEFGHI";
      char s2[16]="VECTOR";

      int l2=strlen(s2);
      int pos;
      puts("enter position in string s1");
      scanf("%d",&pos);


      memmove(s1+pos+l2,s1+pos,strlen(s1+pos)+1);
      strncpy(s1 + pos, s2,l2);

       printf("%s",s1);
}
