#include<stdio.h>
#include<string.h>

int main()
{
     char s1[]="there";
     char s2[]="are";
     char s3[]="always";
     char s4[]="you";

     char s5[25];

     strcpy(s5,s1);
     strcpy(s5+strlen(s5)," ");
     strcpy(s5+strlen(s5),s2);
     strcpy(s5+strlen(s5)," ");
     strcpy(s5+strlen(s5),s3);
     strcpy(s5+strlen(s5)," ");
     strcpy(s5+strlen(s5),s4);

     printf("%s",s5);




}
