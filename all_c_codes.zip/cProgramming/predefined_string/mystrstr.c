#include<stdio.h>
int main()
{
    char arr[30]="This is string";
    char s1[5]="is";


}
