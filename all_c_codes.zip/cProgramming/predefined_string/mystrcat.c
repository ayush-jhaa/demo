#include<stdio.h>
#include<string.h>

int main()
{
    char str[20];
    scanf("%s",str);

    char p;
    scanf("%c",&p);

    char *q=str;
    int cnt=0;

    while(*q)
    {
         if(p==*q)
         {
	    cnt++;
	 }
	 q++;
    }

    printf("%d",cnt);
}
