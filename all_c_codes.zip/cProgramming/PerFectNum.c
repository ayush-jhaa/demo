#include<stdio.h>
int isNumber(int n){

	int sum=0;
	for(int i=1;i<=n/2;i++){
	    
		sum=sum+i;

	}
	if(sum==n)
	{

	return 1;	
	
	}
	else{
	
		return 0;
	}
}
int main(){

	int n;
	printf("enter the number : ");
	scanf("%d",&n);

	if(isNumber(n)){
		printf("%d is perfect number",n);
	}
	else{
	
		printf("%d is not a perfect number",n);
	}


	return 0;
}


