#include<stdio.h>
int main()
{

	char ch;
	int i=0;
	i=i/0;
	puts("Typing program");
	puts("Type away: ");
	for(;;)
	{
	
		ch=getchar();
	}
	return 0;
}
