#include<stdio.h>

unsigned long int fct (unsigned long int n)
{
	if (n==1)
	return 1;

	return (n*fct(n-1));


}

int main()
{
	unsigned long int n;
	scanf("%ld",&n);

	fct(n);
	printf("%ld",fct(n));

}
