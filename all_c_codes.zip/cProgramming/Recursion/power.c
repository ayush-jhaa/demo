#include<stdio.h>
int power(int,int);

int main()
{

	int n,m;
	puts("enter number: "); scanf("%d",&n);
	puts("enter power: "); scanf("%d",&m);

	printf("%d",power(n,m));

}

int power(int a,int b)
{

	if(b==0)
	return 1;

	return a*power(a,b-1);
}
