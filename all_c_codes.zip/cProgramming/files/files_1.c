#include<stdio.h>
int main(int argc, char **argv)
{
    FILE *fp;

    fp=fopen(argv[1],argv[2]);

    if(fp==0)
    printf("file is not there");

    else
    printf("file is there");
}
