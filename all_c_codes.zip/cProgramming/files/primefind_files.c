#include<stdio.h>
#include<stdlib.h>
int count;

void print(int *arr);
int isprime(int num)
{
      int i=2;
      if(num==1)
	return 0;

      for(;i<num;i++)
       {
           if(num%i==0)
	     return 0;
       }
      return 1;
}

int *Input()
{
    int *p;
    int min,max,i;
    printf("enter min and max num "); scanf("%d %d",&min,&max);

    for(min;min<=max;min++)
    {
        if(isprime(min))
         {
	    p=realloc(p,sizeof(int)*(count+1));
	    p[count]=min;
	    count++;
	 }
    }
    return p;
}

int main(int argc, char *argv[])
{
    FILE *fp;
    int  *arr,i;
    arr=Input();

    print(arr);

    fp=fopen(argv[1],"w");
    for(i=0;i<count;i++)
    {
       fprintf(fp,"%d ",arr[i]);
    }
   
    fclose(fp);
}

void print(int *arr)
{
	int i;
   for(i=0;i<count;i++)
    {
        printf("%d ",arr[i]);
    }
}
