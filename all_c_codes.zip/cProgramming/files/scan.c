#include <stdio.h>

int main()
{
    char str[20];
    scanf("%s",str);
    printf("%s",str);

    return 0;
}
