#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
    FILE *src,*dest;
    int  c;
    if(argc !=3)
    {
       printf("wrong number of argument");
       exit(1);
    }

    if((src=fopen(argv[1],"r"))==NULL)
      {
          printf("can't open file");
	  exit(1);
      }
    
    if((dest=fopen(argv[2],"w"))==NULL) 
      {
          printf("can't open file dest");
	  exit(1);
      }

    while((c=fgetc(src))!=EOF)
     {
         fputc(c,dest);
     }
    fclose(src);
    fclose(dest);
    return 0;
}
