#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
    FILE *fptr;
    char str[20];

    if(argc !=2)
    {
        printf("argument are not 3");
	exit(1);
    }
    fptr=fopen(argv[1],"r");

    while(fgets(str,20,fptr)!=NULL)
    // printf("%s",str); 
    puts(str);

    fclose(fptr);
   
    return 0;
}
