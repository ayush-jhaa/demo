#include<stdio.h>
#include<stdlib.h>
int main()
{
    FILE *fptr;
    char str[30];
    if((fptr=fopen("test","w"))==NULL)
     {
         printf("ERROR IN OPENING");
	 exit(1);
     }
    printf("Enter the text");
    scanf("%[^\n]s",str);
  //    fgets(str,30,stdin);
	   fputs(str,fptr);

    fclose(fptr);
    return 0;
}
