#include <stdio.h>

int main(int argc, char *argv[]) {
    FILE *fptr;
    char ch[30];

    fptr = fopen(argv[1], "w");

    while ((fgets(ch, 30, stdin)) != NULL) {
        fputs(ch, fptr);
//        fputs("\n", fptr);
    }

    fclose(fptr);

    return 0;
}
