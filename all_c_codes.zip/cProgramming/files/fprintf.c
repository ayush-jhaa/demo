#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
    FILE *fp;
    char name[10];
    int age;

    fp=fopen(argv[1],"w");

    printf("enter your name and age");
    scanf("%s %d",name,&age);
    fprintf(fp,"My name is %s and my age is %d",name,age);
    fclose(fp);
}
