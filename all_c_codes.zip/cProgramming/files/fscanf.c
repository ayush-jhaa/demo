#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
    FILE *fp;
    char name[20];
    int age;

    fp=fopen(argv[1],"r");
    fscanf(fp,"%s %d",name,&age);
    printf("%s %d",name,age);
    fclose(fp);
}
