#include<stdio.h>

int main(){

	int x=-3,y=6;
	printf("before loop x=%d,y=%d\n",x,y);

	for(x=7,y=0;x>y;x--,y++){
	
		printf("Inside the loop: x=%d y=%d\n",x,y);
	}

	printf("after loop : x=%d y=%d",x,y);
}
