#include<stdio.h>
#include<stdlib.h>
int main(int argc,char **argv)
{
    int a,b,sum;

    a= atoi(argv[1]);
    b= atoi(argv[3]);

    switch(argv[2][0])
    {
       case '+': sum=a+b; 
		 printf("%d",sum);
		 break;
      
      case '-': sum=a-b;
                 printf("%d",sum);
                 break;
      case '*': sum=a*b;
                 printf("%d",sum);
                 break;
      case '/': sum=a/b;
                 printf("%d",sum);
                 break;

    }
}
