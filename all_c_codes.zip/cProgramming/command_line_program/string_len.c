#include <stdio.h>
int my_strlen(const char *);
int main(int argc,char **argv)
{
   int l;

   l=my_strlen(argv[1]);
   printf("%d",l);
}

int my_strlen(const char *p)
{
   int i;
   for(i=0;p[i];i++);

   return  i;
}
