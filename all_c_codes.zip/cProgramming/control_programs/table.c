#include<stdio.h>

int main(){
   
	int min=5,max=10;
//	printf("min value :"); scanf("%d",&min);

//	printf("max value :"); scanf("%d",&max);



	for(int min=1; min<=5; min++,printf("\n"))
	
		for(int j=1;j<=10;j++)
		
			printf("%d", min*j);
		
	

