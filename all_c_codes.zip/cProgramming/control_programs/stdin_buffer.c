#include<stdio.h>
#include<stdio_ext.h>
int main()
{
	char ch;
	do{
		printf("Enter a char(# to stop):");
		scanf("%c",&ch);//ch=getchar();
//		__fpurge(stdin);//clears the stdin buffer.
		//fflush(stdin);
	//	while(getchar()!='\n');	
		
		printf("ch=%c\n",ch);	
	}while(ch!='#');
	printf("after loop\n");

}

