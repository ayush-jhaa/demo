#include<stdio.h>
#include<unistd.h>
int main()
{
	int i,j,n;
	printf("Enter n: lines:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n-i;j++)
		{//print n-i spaces
		  printf(" ");
		}
		for(j=1;j<=i;j++)
		{//iterates i times, to print i *s
		  printf("* ");	
		  fflush(stdout);
//	  	sleep(1);//delay of 1 second  
		usleep(100000);//micro-second delay
		}

	printf("\n");
	}



}
