#include<stdio.h>

#define print(x) printf(#x)

int main()
{
	print(Hello);

	return 0;
}


