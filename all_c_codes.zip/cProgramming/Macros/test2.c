#include<stdio.h>

int call(int a,int b)
{
      b=a+b;
      return b;
}

int main()
{
	int a,b=0;
     
     for(a=0;a<=500000;a++)
     {
          call(a,b);
     }	     
 
     printf("%d",b);
}
