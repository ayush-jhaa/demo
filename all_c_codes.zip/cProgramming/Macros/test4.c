#include <stdio.h>

//#define paste(a, b) a##b

int main() {
    int a = 3, b = 6;
    printf("%d", ab);
    return 0;
}

