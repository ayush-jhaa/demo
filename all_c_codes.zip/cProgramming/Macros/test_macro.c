#include<stdio.h>
/*#define floatptr float*
#define intptr int*
int main()
{
   floatptr f1;
   intptr i1;
}
*/
#define call(x,y)x##y
void main()
{
	int x=5,y=10,xy=20;
	printf("%d",xy+call(x,y));
}
