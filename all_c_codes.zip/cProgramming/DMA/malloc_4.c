#include<stdio.h>
#include<stdlib.h>
int main()
{
   char *p;
   p=malloc(sizeof(char)*10);

   printf("enter the string");
   scanf("%s",p);

   printf("%s",p);
}
