#include<stdio.h>
#include<stdlib.h>
int main()
{ 
     int r,c,**p;
     int i,j;
     printf("enter the rows and coloumn");
     scanf("%d%d",&r,&c);

     p=malloc(sizeof(int *)*r);

     for(i=0;i<r;i++)
     p[i]=malloc(sizeof(int)*c);

     printf("enter the elements\n");
     for(i=0;i<r;i++)
     for(j=0;j<c;j++)
      scanf("%d",&p[i][j]);

     for(i=0;i<r;i++)
     {
        for(j=0;j<c;j++)
        printf("%d ",p[i][j]);

	printf("\n");
     }
}
