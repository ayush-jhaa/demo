#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
      char **p;
      int n,i,j;
      printf("enter the size");
      scanf("%d",&n);

      p=malloc(sizeof(char*)*n);
      char s[10];

      for(int i=0;i<n;i++)
      p[i]=malloc(sizeof(char)*10);

     for(int i=0;i<n;i++)
      scanf("%s",p[i]);

      for(int i=0;i<n;i++)
      printf("%s \n",p[i]);

      //string sort
      for(i=0;i<n-1;i++)
      {
         for(j=0;j<n-1-i;j++)
           {
	     if(strcmp(p[j],p[j+1])>0)
		      {
		         strcpy(s,p[j]);
			 strcpy(p[j],p[j+1]);
			 strcpy(p[j+1],s);
		      }
	   }
      }

     printf("\nafter sorting");

     for(i=0;i<n;i++)
      {
         printf("%s\n",p[i]);
      }
}
