#include<stdio.h>
#include<stdlib.h>

int  main()
{
    char *p[5];
    int i;

    for(i=0;i<5;i++)
    p[i]=malloc(sizeof(char)*10); 

    printf("enter 5 strings");

    for(i=0;i<5;i++)
    scanf("%s",p[i]);

    for(i=0;i<5;i++)
    printf("%s\n",p[i]);
}
