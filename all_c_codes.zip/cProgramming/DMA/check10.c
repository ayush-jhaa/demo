#include<stdio.h>
#include<stdlib.h>
void pass(int *p) {
   p=realloc(p,1*sizeof(*p));
   *p=12;
   printf("%d\n",*p);
}

int main() {
  
  int *x ;
  pass(x);
  
  printf("%d",++*x);
  
  
  return 0;
}

