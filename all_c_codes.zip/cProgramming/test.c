#include<stdio.h>

int main(){

	int c='75';

	//int  c;
//	scanf("%c",&c);

	printf("%d\n",c);
	printf("%c",c);
}
