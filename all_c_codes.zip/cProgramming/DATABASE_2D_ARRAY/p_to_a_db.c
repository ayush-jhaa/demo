#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int cnt=0;

void menu(void)
{
   printf("--------------menu---------\n");
   printf("i:- input p:- print s:- sort q:- quit d:- delete\n");
}

void *input(char (*ptr)[20])
{
     ptr=realloc(ptr,(cnt+1)*sizeof(*ptr));
     printf("enter the names: ");
     __fpurge(stdin);
     fgets(ptr[cnt],20,stdin);
     cnt++;

     return ptr;
}

void delete(char (*p)[20])
{
      int i;
      if(cnt==0)
      {
         printf("data is not there\n");
	 return ;
      }

      printf("enter index to delete");
      scanf("%d",&i);

      memmove(p+i,p+i+1,(cnt-1-i)*sizeof(*p));
      --cnt;

}

void sort(char (*p)[20])
{
     int i,j;
     char temp[20];

     for(i=0;i<cnt-1;i++)
        {
	   for(j=0;j<cnt-1-i;j++)
	    {
	      if(strcmp(p[j],p[j+1])>0)

		   strcpy(temp,p[j]);
	           strcpy(p[j],p[j+1]);
		   strcpy(p[j+1],temp);
	    }
	}
}

void print(char (*ptr)[20])
{
    if (cnt==0)
    {
	    printf("data is not there\n");
             return;
    }
     int i=0;

     for(i=0;i<cnt;i++)
     {
         printf("%s",ptr[i]);
     }
}

int main()
{
   char (*names)[20]=NULL;
   char choice;

   while(1)
   {
     menu();
     __fpurge(stdin);
     scanf("%c",&choice);

     switch(choice)
       {
           case 'i': names=input(names);
		     break;
	   case 'd': delete(names);
		     break;
	   case 's': sort(names);
		     break;
	   case 'p': print(names);
         	     break;
	   case 'q': return 0;
       }
   }
}
