#include<stdio.h>
#include<string.h>
#define MAX 10
int cnt=0;
void printmenu(void)
{
  printf("choose one of this operations:\n");
  printf("p:-print q:-quit s:-sort d:-delete i:-input\n");
}

void Input(char (*ptr)[20])
{
   if(cnt==MAX)
   {
     printf("memory is full");
     return ;
   }
   
   printf("enter name :");
   __fpurge(stdin);
   fgets(ptr[cnt],20,stdin);
   cnt++;
}

void delete(char (*p)[20])
{
     int i;
     if(cnt==0)
     {
      printf("record are'nt found");
      return;
     }

     printf("enter the index to delete:");
     scanf("%d",&i);

     memmove(p+i,p+i+1,(cnt-1-i)*sizeof(*p));
     cnt--;

}

void sort(char (*p)[20])
{
   int i,j;
   char temp[20];
  for(i=0;i<cnt-1;i++)
    {
       for(j=0;j<cnt-1-i;j++)
	  {
	     if(strcmp(p[j],p[j+1])>0)
	     {
	        strcpy(temp,p[j]);
		strcpy(p[j],p[j+1]);
		strcpy(p[j+1],temp);
	     }
	  }
    } 
}

void Print(char (*ptr)[20])
{
    int i=0;
    if(cnt==0)
    {
       printf("nothing present to print\n");
       return;
    }

    for(i=0;i<cnt;i++)
    printf("name:-%d %s",i,ptr[i]);
}
    

int main()
{
   char names[10][20];
   char choice;

   while(1)
   {
       printmenu();
       __fpurge(stdin);
       scanf("%c",&choice);

       switch(choice)
       {
            case 'i': Input(names);
		      break;
	    case 'd': delete(names);
		      break;
	    case 's': sort(names);
		      break;
	    case 'p': Print(names);
		      break;
	    case 'q': return 0;
       }
   }
}
