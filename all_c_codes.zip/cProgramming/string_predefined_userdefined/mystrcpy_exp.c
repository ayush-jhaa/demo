#include<stdio.h>
#include<string.h>

char *mystrcpy(char *desti,const char* src)
{
   int i=0;
   
   while(src[i]) 
   {
       desti[i]=src[i];
       i++;
   }

   desti[i]='\0';
   return desti;
}

int main()
{
     char s1[20];
   //puts("enter the source:");
     scanf("%s",s1);
     char s2[20];
     scanf("%s",s2);

     char s3[50];

//     mystrcpy(s3,s1);
//     mystrcpy(s3+strlen(s3)," ");
//     mystrcpy(s3+strlen(s3),s2);
       mystrcpy(s1+1,s2+1);
     printf("%s",s1);
   
}
