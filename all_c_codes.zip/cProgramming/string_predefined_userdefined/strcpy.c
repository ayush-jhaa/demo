#include<stdio.h>
#include<string.h>

int main()
{
     char str[20]="abcdefgh";
     strcpy(str+2,str);

    printf("%s",str); 
}
