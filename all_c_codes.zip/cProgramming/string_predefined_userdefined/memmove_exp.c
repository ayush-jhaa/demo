#include<stdio.h>
#include<string.h>
int main()
{
    char s1[]="example";
    char s2[]="helloworld";

    char*p=s1;
    char*q=s2;

    memmove(p+1,q+1,4);

    printf("%s",s1);
}
