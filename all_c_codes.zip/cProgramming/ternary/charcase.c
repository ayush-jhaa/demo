#include<stdio.h>
int main()
{

	char c,t;
	printf("enter the character :");
	scanf("%c",&c);

	(c>=65 && c<=90)? printf(" lower case"):(c>=97 && c<=122)?printf("uppercase"):(c>=48 && c<=57)?printf("numbers"):printf("special character");
}
