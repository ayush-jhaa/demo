#include <stdio.h>

int main() {
    int choice, temp;
    float converted;

    printf("Enter your choice (1 for Celsius to Fahrenheit, 2 for Fahrenheit to Celsius): ");
    scanf("%d", &choice);

    printf((choice == 1) ? "Enter temperature in Celsius: " : "Enter temperature in Fahrenheit: ");
    scanf("%d", &temp);

    converted = (choice == 1) ? (temp * 9.0 / 5.0) + 32 : (temp - 32) * 5.0 / 9.0;

    printf((choice == 1) ? "%d Celsius = %.2f Fahrenheit\n" : "%d Fahrenheit = %.2f Celsius\n", temp, converted);

    return 0;
}

