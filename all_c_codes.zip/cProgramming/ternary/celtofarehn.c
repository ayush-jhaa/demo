#include <stdio.h>

int main() {
    int choice, temp;
    float converted;

    printf("Enter your choice (1 for Celsius to Fahrenheit, 2 for Fahrenheit to Celsius): ");
    scanf("%d", &choice);

    choice = (choice != 1 && choice != 2) ? -1 : choice;

    printf("Enter temperature: ");
    scanf("%d", &temp);

    converted = (choice == 1) ? (temp * 9.0 / 5.0) + 32 : (temp - 32) * 5.0 / 9.0;

    (choice == 1) ? printf("%d Celsius = %.2f Fahrenheit\n", temp, converted)
                  : printf("%d Fahrenheit = %.2f Celsius\n", temp, converted);

    return 0;
}

