#include <stdio.h>
#include <stdlib.h>

// Function prototypes
void f2(void);
void f1(void);

// Function definitions
int main1() {
    printf("in main1....\n");
    f2();
    printf("in main\n");
    exit(0);
}

void f1() {
    printf("in f1\n");
}

void f2() {
    printf("in f2\n");
    f1(); // Call to f1
    printf("in f2\n");
}

