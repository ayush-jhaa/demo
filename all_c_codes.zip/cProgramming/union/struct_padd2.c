#include<stdio.h>
#pragma pack(3)
struct student
{
	int r;             
	double s;
	float p;
};                           
int main()
 {
	struct student v;
	printf("%d\n",sizeof(v));
 	
 }
