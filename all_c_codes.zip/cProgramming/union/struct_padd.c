#include<stdio.h>
struct student
{
	double r;             
	char s;
	int p;
};                           
 main()
 {
	struct student v;
	printf("%ld\n",sizeof(v));
 	
 }

