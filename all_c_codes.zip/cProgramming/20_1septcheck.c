#include<stdio.h>
int main()
{
int d=2;
printf("welcome to a program with a bug!!!\n");
scanf("%d",d);

printf("you gave me :%d",d);
return 0;


}
