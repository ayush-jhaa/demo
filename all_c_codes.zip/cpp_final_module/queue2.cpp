#include<iostream>
using namespace std;

int n=-1;
class queue
{
   int size;
   int *arr=NULL;

	public:
  queue()
  {
     cout<<"enter size of queue"<<endl;
     cin>>size;
     arr=new int[size];

  }
   void add(void)
   {
      for(int i=0;i<size;i++)
      {
	      cin>>arr[i];
      		n++;
      }
   }

   void print(void)
   {
       for(int i=0;i<size;i++)
       cout<<arr[i]<<" ";
   }

   void remove(void)
   {
      int *p=NULL;
      p=new int[size-1];
      

      if(n==-1)
      {
       cout<<"queue is empty"<<endl;
       return;
      }


      for(int i=1;i<size;i++)
      {
         p[i-1]=arr[i];
      }


      n--;
      size--;

      delete []arr;

      arr=new int [size];

      for(int i=0;i<size;i++)
      {
         arr[i]=p[i];
      }

      delete []p;
   }


};

int main()
{
    queue p;
    int pop,i;

    cout<<"add data to queue"<<endl;
    p.add();
    cout<<endl;
    p.print();

    cout<<"delete the data from queue"<<endl;
    cout<<"enter no. data to pop"<<endl;
    cin>>pop;

    if(pop>(n+1))
    {
      cout<<"mention size is bigger than queue size";
      return 0;
    }

    for(i=0;i<pop;i++)
    p.remove();

    cout<<endl;
    p.print();
}
