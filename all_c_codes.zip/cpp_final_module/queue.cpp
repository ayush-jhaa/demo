#include<iostream>
using namespace std;

int n=-1;
class queue
{
   int size;
   int *arr=NULL;

	public:
  queue()
  {
     cout<<"enter size of queue"<<endl;
     cin>>size;
     arr=new int[size];

  }
   void add(void)
   {
      for(int i=0;i<size;i++)
      {
	      cin>>arr[i];
      		n++;
      }
   }

   void print(void)
   {
       for(int i=0;i<size;i++)
       cout<<arr[i]<<" ";
   }

   void remove(void)
   {
      if(n<0)
      {
       cout<<"queue is empty"<<endl;
       return;
      }

      int *temp=arr;
      arr++;
      delete temp;
      n--;
      size--;
      
   }


};

int main()
{
    queue p;

    cout<<"add data to queue"<<endl;
    p.add();
    cout<<endl;
    p.print();
    cout<<endl;

    cout<<"delete the data from queue"<<endl;
    p.remove();

    cout<<endl;
    p.print();
}
